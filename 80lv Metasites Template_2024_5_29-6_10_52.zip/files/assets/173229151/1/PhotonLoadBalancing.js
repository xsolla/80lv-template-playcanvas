class PhotonLoadBalancing {
    constructor(app) {
        if (!window.Photon) {
            console.error('window.Photon not available');
            return;
        }
        console.log('Photon: constructor');

        this.app = app;
        this.app.currentRoomName = '';
        this.app.inRoom = false;


        this.appId = 'aed172b7-ba7b-4f28-87dc-a0860a8f24a2'; // 2000
        
        this.roomName = 'XSOLLA_ROOM';
        this.region = 'us';

        this.appVersion = '2.0'; // '1.0'
        this.wss = true;
        this.regions = {
            'Select Region': 'default',
            'Asia, Singapore': 'asia',
            'Australia, Melbourne': 'au',
            'Chinese Mainland (See Instructions) Shanghai': 'cn',
            'Canada, East Montreal': 'cae',
            'Europe, Amsterdam': 'eu',
            'India, Chennai': 'in',
            'Japan, Tokyo': 'jp',
            'South America, Sao Paulo': 'sa',
            'South Korea, Seoul': 'kr',
            'USA, East Washington': 'us',
            'USA, West San José': 'usw'
        };

        this.app.photonClient = new Photon.LoadBalancing.LoadBalancingClient(this.wss ? 1 : 0, this.appId, this.appVersion);
        this.app.photonClient.app = this.app;


        this.app.photonClient.onStateChange = (state) => {
            if (state === Photon.LoadBalancing.LoadBalancingClient.State.ConnectedToNameServer) {
                this.app.photonClient.connectToRegionMaster(this.region);
                // this.app.photonClient.getRegions((error, regions) => {
                //     console.log('121321231321');
                //     if (error) {
                //         console.error('Photon: Error getting regions: ', error);
                //         return;
                //     }

                //     console.log('Photon: Available regions: ', regions);
                //     const bestRegion = this.app.photonClient.selectRegion(regions);
                //     console.log('Photon: Best region selected: ', bestRegion);
                //     this.app.photonClient.connectToRegionMaster(bestRegion);
                // });
            }

            if (state === Photon.LoadBalancing.LoadBalancingClient.State.ConnectedToMaster) {
                // clearInterval(this.interval_PhotonJoinRandomOrCreateRoom);
                // this.interval_PhotonJoinRandomOrCreateRoom = null;
                clearInterval(this.interval_PhotonCreateRoom);
                this.interval_PhotonCreateRoom = null;
                clearInterval(this.interval_PhotonJoinRoom);
                this.interval_PhotonJoinRoom = null;

                const rooms = this.app.photonClient.availableRooms();
                if (rooms.length > 0) {
                    let roomName = null;
                    let playerCount = Infinity;
                    for (let i = 0; i < rooms.length; i++) {
                        const room = rooms[i];
                        if (room.playerCount < playerCount && room.name === this.roomName) {
                            playerCount = room.playerCount;
                            roomName = room.name;
                        }
                    }

                    if (roomName !== null) {
                        console.log('Photon: Try JoinRoom: ' + roomName);
                        this.photonJoinRoom(roomName);
                    } else {
                        console.log('Photon: Try CreateRoom');
                        this.photonCreateRoom();
                    }
                } else {
                    console.log('Photon: Try CreateRoom');
                    this.photonCreateRoom();
                }
            }

            this.app.fire('photonClient:stateChange', state);
        };

        this.app.photonClient.onJoinRoom = (createdByMe) => {
            console.log('Photon: onJoinRoom ' + createdByMe);
            this.app.inRoom = true;
            const myRoom = this.app.photonClient.myRoom();
            myRoom.setMaxPlayers(0);
            console.log(myRoom);
            this.app.currentRoomName = myRoom.name;
            this.app.fire('photonClient:onJoinRoom', createdByMe);
        };

        this.app.photonClient.onRoomListUpdate = (rooms) => {
            console.log('Photon: onRoomList', rooms);
            this.app.fire('photonClient:onRoomList', rooms);
        };

        this.app.photonClient.onActorJoin = (actor) => {
            console.log('Photon: onActorJoin', actor);
            this.app.fire('photonClient:onActorJoin', actor);
        };

        this.app.photonClient.onActorLeave = (actor) => {
            console.log('Photon: onActorLeave', actor);
            this.app.fire('photonClient:onActorLeave', actor);
        };

        this.app.photonClient.onEvent = (code, content, actorNr) => {
            // console.log('Photon: onEvent ' + code + ' ' + content + ' ' + actorNr);
            switch (code) {
                case 0: {
                    if (actorNr === this.app.photonClient.myActor().actorNr) 
                        return;

                    this.app.fire('photonClient:onUpdatePlayerPosition', content, actorNr);
                    break;
                }
                default: {
                    return;
                }
            }
        };

        this.app.photonClient.onError = (errorCode, errorMsg) => {
            console.log('Photon: onError ' + errorCode + ': ' + errorMsg);
            this.app.inRoom = false;
            this.app.fire('photonClient:onError', errorCode);
        };


        this.interval_ReconnectToMaster = null;
        // this.interval_PhotonJoinRandomOrCreateRoom = null;
        this.interval_PhotonCreateRoom = null;
        this.interval_PhotonJoinRoom = null;
        this.app.photonClient.connectToNameServer();
    }


    reconnectToMaster() {
        if (this.interval_ReconnectToMaster !== null)
            return;

        this.interval_ReconnectToMaster = setInterval(() => {
            if (this.app.userAFK) 
                return;

            if (this.app.photonClient.reconnectToMaster()) {
                console.log('Photon: reconnectToMaster myActor: ' + this.app.photonClient.myActor().actorNr + ' inRoom: ' + this.app.inRoom + ' isInLobby: ' + this.app.photonClient.isInLobby());
            } else {
                if (this.app.photonClient.isConnectedToMaster() || this.app.photonClient.isConnectedToNameServer())
                    this.app.photonClient.disconnect();

                this.app.photonClient.connectToNameServer();
            }

            clearInterval(this.interval_ReconnectToMaster);
            this.interval_ReconnectToMaster = null;
        }, 500);
    }


    // photonJoinRandomOrCreateRoom() {
    //     if (this.interval_PhotonJoinRandomOrCreateRoom !== null) 
    //         return;

    //     this.interval_PhotonJoinRandomOrCreateRoom = setInterval(() => {
    //         console.log('Photon: photonJoinRandomOrCreateRoom myActor: ' + this.app.photonClient.myActor().actorNr + ' inRoom: ' + this.app.inRoom + ' isInLobby: ' + this.app.photonClient.isInLobby());

    //         if (this.app.inRoom) {
    //             clearInterval(this.interval_PhotonJoinRandomOrCreateRoom);
    //             this.interval_PhotonJoinRandomOrCreateRoom = null;
    //             return;
    //         }

    //         if (!this.app.photonClient.isInLobby())
    //             return;

    //         this.joinRandomOrCreateRoom();
    //     }, 500);
    // }


    photonCreateRoom() {
        if (this.interval_PhotonCreateRoom !== null) 
            return;

        this.interval_PhotonCreateRoom = setInterval(() => {
            console.log('Photon: photonCreateRoom myActor: ' + this.app.photonClient.myActor().actorNr + ' inRoom: ' + this.app.inRoom + ' isInLobby: ' + this.app.photonClient.isInLobby());

            if (this.app.inRoom) {
                clearInterval(this.interval_PhotonCreateRoom);
                this.interval_PhotonCreateRoom = null;
                return;
            }

            if (!this.app.photonClient.isInLobby())
                return;

            let roomName = null;
            const rooms = this.app.photonClient.availableRooms();
            if (rooms.length > 0) {
                let playerCount = Infinity;
                for (let i = 0; i < rooms.length; i++) {
                    const room = rooms[i];
                    if (room.playerCount < playerCount && room.name === this.roomName) {
                        playerCount = room.playerCount;
                        roomName = room.name;
                    }
                }
            }

            if (roomName !== null) {
                clearInterval(this.interval_PhotonCreateRoom);
                this.interval_PhotonCreateRoom = null;
                console.log('Photon: Try JoinRoom: ' + roomName);
                this.photonJoinRoom(roomName);
            } else {
                this.createRoom();
            }
        }, 500);
    }


    photonJoinRoom(roomName) {
        if (this.interval_PhotonJoinRoom !== null) 
            return;

        this.interval_PhotonJoinRoom = setInterval(() => {
            console.log('Photon: photonJoinRoom myActor: ' + this.app.photonClient.myActor().actorNr + ' inRoom: ' + this.app.inRoom + ' isInLobby: ' + this.app.photonClient.isInLobby());

            if (this.app.inRoom) {
                clearInterval(this.interval_PhotonJoinRoom);
                this.interval_PhotonJoinRoom = null;
                return;
            }

            if (!this.app.photonClient.isInLobby())
                return;

            this.joinRoom(roomName);
        }, 500);
    }


    createRoom() {
        if (!this.app.photonClient.isConnectedToMaster()) 
            return;

        console.log('Photon: createRoom');
        const options = {
            maxPlayers: 0
        };
        this.app.photonClient.createRoom(this.roomName, options);
    }


    joinRoom(roomName) {
        if (!this.app.photonClient.isConnectedToMaster()) 
            return;

        console.log('Photon: joinRoom');
        this.app.photonClient.joinRoom(roomName);
    }


    // joinRandomRoom() {
    //     if (!this.app.photonClient.isConnectedToMaster()) 
    //         return;

    //     console.log('Photon: joinRandomRoom');
    //     this.app.photonClient.joinRandomRoom();
    // }


    // joinRandomOrCreateRoom() {
    //     if (!this.app.photonClient.isConnectedToMaster()) 
    //         return;

    //     console.log('Photon: joinRandomOrCreateRoom');
    //     const createOptions = {
    //         maxPlayers: 0
    //     };
    //     this.app.photonClient.joinRandomOrCreateRoom(undefined, this.roomName, createOptions);
    // }
}
