const UserSkin = pc.createScript('userSkin');


UserSkin.prototype.init = function () {
    this.invisibleMode = false;
    this.invisible = false;
};


UserSkin.prototype.setSkin = function (skinUrl, userId) {
    const user = CoreScript.users.userPool[userId];
    if (user && skinUrl && user.currentSkinUrl !== skinUrl && skinUrl && userId) {
        utils.loadGlbContainerFromUrl(skinUrl, null, name, function (err, asset) {
            if (asset.resources[0].model) {
                const avatar = user.findByName('PlayerModel');
                const renderRootEntity = asset.resource.instantiateRenderEntity();

                if (avatar) {
                    const oldAvatar = avatar.children[avatar.children.length - 1];

                    avatar.addChild(renderRootEntity);
                    avatar.anim.rootBone = renderRootEntity;
                    avatar.anim.activate = true;
                    avatar.anim.reset();
                    avatar.setLocalEulerAngles(180, 0, 180);
                    oldAvatar.destroy();
                }

                user.currentSkinUrl = skinUrl;

                console.log('LOADED AND SETTED NEW SKIN');
            } else {
                console.log(asset.resources);
            }
        }.bind(this));
    }

};
