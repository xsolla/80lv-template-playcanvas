const User = pc.createScript('user');

User.attributes.add('speedDefault', {
    type: 'number',
    default: 32.0
});

User.attributes.add('acceleration', {
    type: 'number',
    default: 4.0
});


User.prototype.init = function (userId, startPosition, directionOfView) {
    this.animStates = {
        Walk: 1,
        StrafeRight: 3,
        StrafeLeft: 2,
        ForwardLeftDiag: 4,
        ForwardRightDiag: 5,
        WalkBack: 6,
        BackwardRightDiag: 7,
        BackwardLeftDiag: 8,
        Jump: 9,
        IDLE: 0
    }

    this.animState = 0;
    this.animBlocked = false;
    this.anim = this.entity.findByName('PlayerModel').anim;
    this.anim.on('jumpEnd', () => {
        this.animBlocked = false;
    });

    this.inFrustum = true;
    this.userId = userId;
    this.actors = this.app.photonClient.myRoomActors();

    this.setSpawnPoint({ position: startPosition, direction: directionOfView });

    this.sphere = new pc.BoundingSphere();
    this.collider = this.entity.findByName('SphereCollider');
    this.sphere.radius = this.collider.getLocalScale().x * 0.5;

    this.height = 2.6;

    this.dtScale = 3.0;
    this.gravity = 9.81;
    this.isGround = true;
    this.groundDistance = 0.0;

    this.jumpVelocity = 0.0;
    this.jumpInitVelocity = this.gravity * 1.8; // this.gravity * 1.8;
    this.isJumping = false;
    this.landing = false;
    this.speedCurrent = 0.0;
    this.speedMax = this.speedDefault;
    this.jumpScale = new pc.Vec3(1.0, 1.0, 1.0);
    this.jumpScaleState = [
        new pc.Vec3(1.0, 1.0, 1.0),
        new pc.Vec3(0.8, 1.2, 0.8),
        new pc.Vec3(1.3, 0.7, 1.3)
    ];

    this.isFlightMode = false;
    this.isFlight = false;

    this.vec3A = new pc.Vec3();
    this.vec3B = new pc.Vec3();
    this.vec3C = new pc.Vec3();
    this.vec3D = new pc.Vec3();
    this.vec3E = new pc.Vec3();
    this.vec3F = new pc.Vec3();
    this.vecLookAt = new pc.Vec3();

    this.rotationReference = this.entity.right.distance(this.entity.forward);
    this.pitch = 0.0;
    this.time = 0.0;
    this.distanceToTarget = 0.0;
    this.noMovement = true;
    this.noMovementTimeout = 0.0;

    this.movementControl = 0.0;
    this.scale = 1.0;
    this.currentPosition = new pc.Vec3();
    this.nextPosition = new pc.Vec3();
    this.targetPosition = new pc.Vec3();
    this.isTeleport = false;
    // this.targetPositions = [];

    this.targetDirection = new pc.Vec3();
    this.upDirection = new pc.Vec3();

    this.respawn();
    this.t = 0.0;
    this.dist = 0.0;
};


User.prototype.postUpdate = function (dt) {
    if (!this.entity.tags.has('MainUser'))
        return;

    if (this.app.player)
        this.app.player.postUpdate(dt);
};


User.prototype.update = function (dt) {
    if (!this.entity.tags.has('MainUser')) {
        if (!this.inFrustum) {
            this.anim.enabled = false;
            if (this.t < 5.0) {
                this.t += dt;
                return;
            }
        } else {
            this.anim.enabled = true;
            if (this.t < /*0.03*/this.dist * 0.001) {
                this.t += dt;
                return;
            }
        }
        this.dist = this.currentPosition.distance(this.app.selfUser.script.user.currentPosition);
        dt = this.t;
        this.t = 0.0;
    } else {
        if (!CoreScript.users.worldBoundingBox.containsPoint(this.currentPosition)) {
            this.respawn();
        }
    }


    // jump Scaling
    const jumpScalingSpeed = 20.0;
    if (!this.isFlightMode) {
        if (this.isJumping) {
            if (this.jumpScale.distance(this.jumpScaleState[1]) > 0.01) {
                this.jumpScale.lerp(this.jumpScale, this.jumpScaleState[1], Math.min(dt * jumpScalingSpeed, 1.0));
                // this.entity.setLocalScale(this.jumpScale);
                this.landing = false;
            }
        } else {
            if (this.landing) {
                if (this.jumpScale.distance(this.jumpScaleState[0]) > 0.01) {
                    this.jumpScale.lerp(this.jumpScale, this.jumpScaleState[0], Math.min(dt * jumpScalingSpeed * 0.5, 1.0));
                    // this.entity.setLocalScale(this.jumpScale);
                }
            } else {
                if (this.jumpScale.distance(this.jumpScaleState[2]) > 0.01) {
                    this.jumpScale.lerp(this.jumpScale, this.jumpScaleState[2], Math.min(dt * jumpScalingSpeed, 1.0));
                    // this.entity.setLocalScale(this.jumpScale);
                } else {
                    this.landing = true;
                }
            }
        }
    } else {
        if (this.isJumping) {
            if (this.jumpScale.distance(this.jumpScaleState[1]) > 0.01) {
                this.jumpScale.lerp(this.jumpScale, this.jumpScaleState[1], Math.min(dt * jumpScalingSpeed, 1.0));
                // this.entity.setLocalScale(this.jumpScale);
            }
        } else {
            if (this.jumpScale.distance(this.jumpScaleState[0]) > 0.01) {
                this.jumpScale.lerp(this.jumpScale, this.jumpScaleState[0], Math.min(dt * jumpScalingSpeed * 0.5, 1.0));
                // this.entity.setLocalScale(this.jumpScale);
            }
        }
    }


    // movement
    if (this.movementControl > 0.0) {
        this.speedCurrent = this.app.coreScript.lerp(this.speedCurrent, this.speedMax * this.movementControl, Math.min(dt * this.acceleration, 1.0), 0.01);
    } else {
        this.speedCurrent = this.app.coreScript.lerp(this.speedCurrent, 0.0, Math.min(dt * this.acceleration, 1.0), 0.01);
    }

    const dtScale = dt * this.dtScale;
    this.currentPosition.copy(this.entity.getPosition());

    if (this.speedCurrent > 0.0) {
        if (this.currentPosition.distance(this.targetPosition) > this.speedCurrent * dt) {
            this.nextPosition.copy(this.targetPosition).sub(this.currentPosition).normalize();
            this.nextPosition.mulScalar(this.speedCurrent * dt);
            this.nextPosition.add(this.currentPosition);
        } else {
            this.nextPosition.copy(this.targetPosition);
        }
    } else {
        this.nextPosition.copy(this.currentPosition);
    }

    // gravity
    if (this.entity.tags.has('MainUser') || (this.entity.tags.has('BotUser') && (this.isJumping || !this.landing))) {
        // if (!this.isFlight) {
        //     this.nextPosition.y = this.applyGravity(dtScale, dt);
        // } else if (this.isJumping) {
        //     this.nextPosition.y += this.jumpInitVelocity * dt;
        // }
        this.nextPosition.y = 0;
    }


    // movement
    let needUpdate = false;
    this.distanceToTarget = 0;
    if (this.currentPosition.distance(this.nextPosition) < 0.01) {
        this.time = 0.0;

        if (!this.isFlight) this.setAnim(this.animStates.IDLE);
    } else {
        this.vec3A.copy(this.nextPosition).sub(this.currentPosition);
        this.vec3A.y = 0.0;
        this.distanceToTarget = this.vec3A.length();

        if (this.distanceToTarget > 0.01) {
            this.targetDirection.copy(this.vec3A);
            this.targetDirection.normalize();

            if (!this.isFlight) {
                if (this.distanceToTarget > 1.0) {
                    // this.setAnimation(this.animationStates.WALKING);
                } else {
                    // this.setAnimation(this.animationStates.WALKING);
                }
            }
        } else {
            if (!this.isFlight) this.setAnim(this.animStates.IDLE);
        }

        var direction = new pc.Vec3();
        direction.sub2(this.nextPosition, this.currentPosition);
        direction.normalize();

        // вычисляем угол между форвардом и направлением движения
        var directionAngleInRadians = Math.acos(pc.math.clamp(this.entity.forward.dot(direction), -1, 1));

        // преобразуем угол в градусы
        var directionAngle = Math.round(directionAngleInRadians * pc.math.RAD_TO_DEG);

        var crossProduct = new pc.Vec3();
        crossProduct.cross(this.entity.forward, direction);

        this.currentPosition.copy(this.nextPosition);
        needUpdate = true;
        this.time += dt;
    }


    if (needUpdate) {
        this.setPosition(this.currentPosition);

        if (crossProduct.y > 0) {
            // left
            if (directionAngle < 25) {
                this.setAnim(this.animStates.Walk);
            } else if (directionAngle <= 60) {
                this.setAnim(this.animStates.ForwardLeftDiag);
            } else if (directionAngle <= 95) {
                this.setAnim(this.animStates.StrafeLeft);
            } else if (directionAngle <= 145) {
                this.setAnim(this.animStates.BackwardLeftDiag);
            } else {
                this.setAnim(this.animStates.WalkBack);
            }

        } else {
            // right
            if (directionAngle < 25) {
                this.setAnim(this.animStates.Walk);
            } else if (directionAngle <= 60) {
                this.setAnim(this.animStates.ForwardRightDiag);
            } else if (directionAngle <= 95) {
                this.setAnim(this.animStates.StrafeRight);
            } else if (directionAngle <= 145) {
                this.setAnim(this.animStates.BackwardRightDiag);
            } else {
                this.setAnim(this.animStates.WalkBack);
            }

        }

        this.noMovementTimeout = 0.0;
    } else {
        this.noMovementTimeout += dt;
    }
};

User.prototype.flightMode = function () {
    if (!this.isFlightMode) {
        this.isFlightMode = true;
    } else {
        this.isFlightMode = false;
    }
    this.isFlight = false;
};


User.prototype.setFlight = function (value) {
    this.isFlight = value;

    if (this.isFlight) {
        this.animBlocked = false;
        // this.setAnim(4);
    }
};


User.prototype.setJumping = function (value) {
    this.isJumping = value;

    if (this.isJumping) {
        if (!this.isFlight) {
            this.setAnim(this.animStates.Jump);
            this.landing = false;
        }
    }
};


User.prototype.jump = function () {
    if (!this.isGround && !this.isFlightMode)
        return;

    this.isJumping = true;
    this.jumpVelocity = this.jumpInitVelocity;

    if (!this.isFlight) this.setAnim(this.animStates.Jump);
};


User.prototype.setSpawnPoint = function (data) {
    this.spawnPoint = {
        position: data.position,
        direction: data.direction
    }
};


User.prototype.respawn = function () {
    this.isTeleport = true;
    this.setTransform(this.spawnPoint);
};


User.prototype.setTransform = function (data) {
    if (data.position !== undefined) {
        this.currentPosition.set(data.position[0], data.position[1], data.position[2]);
        this.targetPosition.copy(this.currentPosition);
        this.setPosition(this.currentPosition);
    }

    if (data.direction !== undefined) {
        this.targetDirection.set(data.direction[0], data.direction[1], data.direction[2]);
        this.upDirection.copy(pc.Vec3.UP);
        // this.lookAt(this.currentPosition, this.targetDirection, this.upDirection);
    }
};


User.prototype.setAnim = function (state) {
    if (state === this.animState) return;

    if (this.animBlocked) return;

    if (state === this.animStates.Jump) { 
        this.animBlocked = true;
        setTimeout(() => {
            this.animBlocked = false;
            this.isJumping = false;
        }, 900);
    }

    this.animState = state;
    this.anim.setInteger('State', state);
}

User.prototype.stopMovement = function () {
    this.movementControl = 0.0;
};


User.prototype.setTargetPosByDirection = function (direction, movementControl) {
    this.targetPosition.set(direction[0], direction[1], direction[2]);
    this.targetPosition.add(this.entity.getPosition());
    this.movementControl = movementControl;
};


User.prototype.setTargetPosByPosition = function (position) {
    this.targetPosition.set(position[0], position[1], position[2]);
    this.movementControl = Math.min(this.targetPosition.distance(this.entity.getPosition()), 1.0);
};

User.prototype.setRotationByAngle = function ({ angle }) {
    var rotation = new pc.Quat();
    rotation.setFromEulerAngles(0, 270 - angle, 0);

    this.entity.setRotation(rotation);
}

User.prototype.setPosition = function (position) {
    this.entity.setPosition(position);
    CoreScript.usersInfo.setPosition(this.userId, position, this.height);
};


User.prototype.lookAt = function (position, direction, up) {
    this.vecLookAt.copy(position);
    this.vecLookAt.add(direction);
    // this.entity.lookAt(this.vecLookAt, up);
};


User.prototype.applyGravity = function (dtScale, dt) {
    let currentY = this.currentPosition.y;
    const targetY = this.getGround();

    this.isGround = false;
    if (Math.abs(currentY - targetY) < this.sphere.radius * 2.0) {
        if (!this.isJumping) {
            this.isGround = true;
            currentY = this.app.coreScript.lerp(currentY, targetY, Math.min(dt * 32.0, 1.0));
            return currentY;
        }
    } else if (currentY - targetY > this.sphere.radius) {
        this.isJumping = true;
    }


    if (this.jumpVelocity > 0.0) {
        this.jumpVelocity -= this.gravity * dtScale;
        if (this.jumpVelocity < 0.0)
            this.jumpVelocity = 0.0;
    }

    if (this.isFlightMode && this.jumpVelocity <= this.gravity)
        this.setFlight(true);

    currentY += this.jumpVelocity * dtScale;
    currentY -= this.gravity * dtScale;


    if (currentY < targetY) {
        currentY = targetY;
        this.isGround = true;
        this.isJumping = false;
        if (this.jumpVelocity > 0.0)
            this.jumpVelocity = 0.0;

        if (!this.isFlight) this.setAnim(this.animStates.Jump);
    }

    return currentY;
};


User.prototype.getGround = function () {
    return 0.0;
};
