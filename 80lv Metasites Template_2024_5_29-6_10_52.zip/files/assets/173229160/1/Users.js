const Users = pc.createScript('users');

Users.attributes.add('botsCount', {
    type: 'number',
    default: 256
});

Users.attributes.add('tplUser', {
    type: 'asset',
    assetType: 'template'
});


Users.prototype.initialize = function () {
    const worldBoundingBox = this.app.scene.root.findByName('WorldBoundingBox');
    const extents = worldBoundingBox.getLocalScale();
    this.worldBoundingBox = new pc.BoundingBox();
    this.worldBoundingBox.center.copy(worldBoundingBox.getPosition());
    this.worldBoundingBox.halfExtents.set(extents.x * 0.5, extents.y * 0.5, extents.z * 0.5);

    this.app.on('user:add', this.userQueueAdd, this);
    // this.app.on('user:add', this.userAdd, this);
    this.app.on('user:setFps', this.setFps, this);
    this.app.on('user:setPing', this.setPing, this);
    this.app.on('user:setName', this.setName, this);
    this.app.on('user:setSkin', this.setSkin, this);
    this.app.on('user:setFlight', this.setFlight, this);
    this.app.on('user:setJumping', this.setJumping, this);
    this.app.on('user:setTransform', this.setTransform, this);
    this.app.on('user:setLookAt', this.setLookAt, this);
    this.app.on('user:setAngle', this.setAngle, this);
    this.app.on('user:setTargetTransform', this.setTargetTransform, this);
    this.app.on('user:remove', this.userQueueRemove, this);
    // this.app.on('user:remove', this.userRemove, this);
    this.app.on('user:simulation', this.onSimulation, this);
};



Users.prototype.initUsers = function () {
    this.sphere = new pc.BoundingSphere();
    this.sphere.radius = 1.22;

    this.spawnAreas = [];
    const spawnAreas = this.app.scene.root.findByTag('SpawnArea');
    for (let i = 0; i < spawnAreas.length; i++) {
        const mat = new pc.Mat4();
        mat.copy(spawnAreas[i].getWorldTransform());
        this.spawnAreas.push(mat);
    }
    this.vec3A = new pc.Vec3();
    this.obb = new pc.OrientedBox();

    this.userQueueTimeout = 0.0;
    this.userQueue = {};

    this.botPool = {};
    this.userPool = {};
    // self user
    this.selfUserId = this.app.photonClient.myActor().userId;
    const data = {
        position: [0.0, 0.0, 0.0],
        directionOfView: [0.0, 0.0, -1.0],
        skinId: Math.round(Math.random() * 31),
        name: this.selfUserId
    };
    this.addUser(this.selfUserId, data);

    console.log('users:isInitialized');
    this.isInitialized = true;
    this.app.fire('users:isInitialized');
};


Users.prototype.getSpawnPoint = function () {
    this.vec3A.set(0.0, 0.0, 0.0);
    this.vec3A.x += Math.random() - 0.5;
    this.vec3A.z += Math.random() - 0.5;
    this.spawnAreas[Math.round(Math.random() * (this.spawnAreas.length - 1.0))].transformPoint(this.vec3A, this.vec3A);
    return [this.vec3A.x, this.vec3A.y/* - 0.2*/, this.vec3A.z];
};


Users.prototype.getDirectionOfView = function () {
    this.vec3A.set(0.0, 0.0, 0.0);
    this.vec3A.x += Math.random() - 0.5;
    this.vec3A.z += Math.random() - 0.5;
    this.vec3A.normalize();
    return [this.vec3A.x, this.vec3A.y, this.vec3A.z];
};


Users.prototype.userQueueAdd = function (userId, selfUser, isBot) {
    if (selfUser) {
        this.userAdd(userId, true);
        return;
    }

    if (isBot) {
        this.userQueue[userId] = 'addBot';
    } else {
        this.userQueue[userId] = 'addUser';
    }
};


Users.prototype.userAdd = function (userId, selfUser) {
    if (this.userPool[userId])
        return;

    if (selfUser) {
        this.userPool[userId] = this.userPool[this.selfUserId];
        delete this.userPool[this.selfUserId];

        CoreScript.usersInfo.usedPool[userId] = CoreScript.usersInfo.usedPool[this.selfUserId];
        delete CoreScript.usersInfo.usedPool[this.selfUserId];

        this.userPool[userId].script.user.userId = userId;
        this.selfUserId = userId;
        return;
    }

    const spawnPoint = this.getSpawnPoint();
    const directionOfView = this.getDirectionOfView();

    this.addUser(userId, { position: spawnPoint, directionOfView: directionOfView });
};


Users.prototype.addUser = function (userId, data, isBot) {
    const item = this.tplUser.resource.instantiate();
    this.app.scene.root.addChild(item);
    item.script.userSkin.init();

    if (userId === this.selfUserId) {
        this.app.selfUser = item;
        item.tags.add('MainUser');
        data.position[1] += 2.0;
        // replace with current nickname
        data.name = 'Current user';
    }

    item.script.user.init(userId, data.position, data.directionOfView);

    CoreScript.usersInfo.addItem(userId, item.script.user, data.name, 60, Math.round(Math.random() * 1100), (userId === this.selfUserId));
    item.script.userSkin.setSkin(data.skinId);

    item.enabled = true;
    item.time = Date.now();

    if (isBot) {
        item.tags.add('BotUser');
        this.botPool[userId] = item;
        return;
    }

    this.userPool[userId] = item;
};


Users.prototype.userQueueRemove = function (userId, isBot) {
    if (userId === this.selfUserId)
        return;

    if (isBot) {
        this.userQueue[userId] = 'removeBot';
    } else {
        this.userQueue[userId] = 'removeUser';
    }
};


Users.prototype.userRemove = function (userId) {
    if (userId === this.selfUserId)
        return;

    const user = this.userPool[userId];
    if (!user)
        return;

    CoreScript.usersInfo.removeItem(userId);

    user.destroy();
    delete this.userPool[userId];
};


Users.prototype.setFps = function (userId, value) {
    CoreScript.usersInfo.setFps(userId, value);
};


Users.prototype.setPing = function (userId, value) {
    CoreScript.usersInfo.setPing(userId, value);
};


Users.prototype.setName = function (userId, value) {
    CoreScript.usersInfo.setName(userId, value);
};


Users.prototype.setSkin = function (userId, skinUrl) {
    const user = this.userPool[userId];
    if (!user)
        return;

    user.script.userSkin.setSkin(skinUrl, userId);
};


Users.prototype.setFlight = function (userId, value) {
    const user = this.userPool[userId];
    if (!user)
        return;

    user.script.user.setFlight(value > 0 ? true : false);
};


Users.prototype.setJumping = function (userId, value) {
    const user = this.userPool[userId];
    if (!user)
        return;

    user.script.user.setJumping(value > 0 ? true : false);
};


Users.prototype.setSpawnPoint = function (userId, data) {
    const user = this.userPool[userId];
    if (!user)
        return;

    user.script.user.setSpawnPoint(data);
};

Users.prototype.setAngle = function (userId, data) {
    const user = this.userPool[userId];
    if (!user) return;

    user.script.user.setRotationByAngle(data);
};

Users.prototype.setTransform = function (userId, data) {
    const user = this.userPool[userId];
    if (!user)
        return;

    user.script.user.setTransform(data);
};


Users.prototype.setTargetTransform = function (userId, data, isBot) {
    if (isBot) {
        const user = this.botPool[userId];
        if (!user)
            return;

        user.script.user.setTargetPosByPosition(data.position);
        return;
    }

    const user = this.userPool[userId];
    if (!user)
        return;

    user.script.user.setTargetPosByPosition(data.position);
};


Users.prototype.onSimulation = function (enabled) {
    if (enabled) {
        if (this.botPool.length > 0)
            return;

        for (let i = 0; i < this.botsCount; i++) {
            const userId = '' + Math.random().toString(36).substring(7);
            this.userQueueAdd(userId, false, true);
        }
    } else {
        for (const key in this.userQueue) {
            if (this.userQueue[key] === 'addBot')
                delete this.userQueue[key];
            // this.userQueueRemove(key, true);
        }
        for (const key in this.botPool) {
            this.userQueueRemove(key, true);
        }
    }
};


Users.prototype.update = function (dt) {
    // console.log(this.app.batcher);
    if (this.app.keyboard.wasReleased(pc.KEY_B))
        this.app.fire('user:simulation', Object.keys(this.botPool).length > 0 ? false : true);


    if (this.app.inRoom) {
        // const rooms = this.app.photonClient.availableRooms();
        // console.log(rooms);
        const actors = this.app.photonClient.myRoomActors();
        UserCounter.userCount = Object.keys(actors).length;
        for (const key in actors) {
            const user = this.userPool[key];
            if (user)
                continue;

            const actor = actors[key];
            if (!actor.isLocal) {
                this.userQueueAdd(key, false);
                // this.userAdd(key, false);
                continue;
            }

            this.userQueueAdd(key, true);
            // this.userAdd(key, true);
        }
        for (const key in this.userPool) {
            const actor = actors[key];
            if (!actor) {
                this.userQueueRemove(key);
                // this.userRemove(key);
            }
        }
    }


    if (this.userQueue && Object.keys(this.userQueue).length > 0) {
        if (this.userQueueTimeout < 0.0) {

            for (const key in this.userQueue) {
                const userId = key;

                if (userId !== null) {
                    const state = this.userQueue[userId];
                    if (state === 'addUser') {
                        this.userAdd(userId, false);
                    } else if (state === 'addBot') {
                        const data = {
                            position: this.getSpawnPoint(),
                            directionOfView: this.getDirectionOfView(),
                            skinId: Math.round(Math.random() * 31),
                            name: Math.random().toString(36).substring(7)
                        };
                        this.addUser(userId, data, true);
                    } else if (state === 'removeUser') {
                        this.userRemove(userId);
                    } else if (state === 'removeBot') {
                        const user = this.botPool[userId];
                        if (user) {
                            CoreScript.usersInfo.removeItem(userId);
                            user.destroy();

                            // for (let i = 0; i < this.app.batcher._dirtyGroups.length; i++) {
                            //     if (this.app.batcher._dirtyGroups[i] === this.batchGroupId) {
                            //         this.app.batcher._dirtyGroups.splice(i, 1);
                            //         i--;
                            //     }
                            // }

                            // for (let i = 0; i < this.app.batcher._batchList.length; i++) {
                            //     if (this.app.batcher._batchList[i].batchGroupId === this.batchGroupId)
                            //         this.app.batcher._batchList[i].notDirty = true;
                            // }

                            delete this.botPool[userId];
                        }
                    }

                    delete this.userQueue[userId];
                    // this.userQueueTimeout = 0.01;

                    if (Object.keys(this.userQueue).length <= 0)
                        console.log('' + Object.keys(this.botPool).length);
                }
            }
        } else {
            this.userQueueTimeout -= dt;
        }
    }


    for (const userId in this.botPool) {
        const user = this.botPool[userId];
        if (!user)
            continue;

        this.vec3A.copy(user.script.user.currentPosition);
        this.vec3A.y += 1.22;
        this.sphere.center = this.vec3A;
        user.script.user.inFrustum = false;

        if (CoreScript.mainCamera.camera.frustum.containsSphere(this.sphere)) {
            user.script.user.inFrustum = true;

            if (!user.script.user.isJumping && Math.random() > 0.999)
                user.script.user.jump();

            if (!user.pathToTravel) {
                user.pathToTravel = this.createPath(user);
                user.pathToTravel.percent = Math.random();
            }

            if (!user.readyToMove) {
                user.pathToTravel.percent += dt * 0.01;
                if (user.pathToTravel.percent >= 1.0)
                    user.pathToTravel = this.createPath(user);

                this.vec3A.set(
                    user.pathToTravel.px.value(user.pathToTravel.percent),
                    user.pathToTravel.py.value(user.pathToTravel.percent),
                    user.pathToTravel.pz.value(user.pathToTravel.percent)
                );

                if (this.vec3A.distance(user.script.user.currentPosition) >= 4.0)
                    user.readyToMove = true;
            } else {
                if (Math.random() > 0.5) { // 0.99
                    this.vec3A.set(
                        user.pathToTravel.px.value(user.pathToTravel.percent),
                        user.pathToTravel.py.value(user.pathToTravel.percent),
                        user.pathToTravel.pz.value(user.pathToTravel.percent)
                    );
                    this.setTargetTransform(userId, { position: [this.vec3A.x, this.vec3A.y, this.vec3A.z] }, true);
                    user.readyToMove = false;
                }
            }
        }
    }
};


Users.prototype.createPath = function (user) {
    const points = [];
    points.push({
        pos: user.script.user.currentPosition.clone(),
        pathLength: 0.0,
        t: 0.0
    });

    for (let i = 1; i < 10; i++) {
        const p = this.getSpawnPoint();
        const pos = new pc.Vec3(p[0], p[1], p[2]);
        points.push({
            pos: pos,
            pathLength: 0.0,
            t: 0.0
        });
    }

    const path = {
        px: new pc.Curve(),
        py: new pc.Curve(),
        pz: new pc.Curve(),
        percent: 0.0
    }
    const curveMode = pc.CURVE_CARDINAL;
    path.px.type = curveMode;
    path.py.type = curveMode;
    path.pz.type = curveMode;

    let pathLength = 0.0;
    for (let i = 1; i < points.length; i++) {
        const point = points[i];
        const prevPoint = points[i - 1];
        const distance = point.pos.distance(prevPoint.pos);
        pathLength += distance;
        point.pathLength = pathLength;
    }

    for (let i = 0; i < points.length; i++) {
        const point = points[i];
        point.t = point.pathLength / pathLength;

        path.px.add(point.t, point.pos.x);
        path.py.add(point.t, point.pos.y);
        path.pz.add(point.t, point.pos.z);
    }

    return path;
};
