const Joystick = pc.createScript('joystick');

Joystick.attributes.add('name', {
    type: 'string'
});

Joystick.attributes.add('screenSide', {
    type: 'string',
    enum: [
        { 'Center': 'Center' },
        { 'Left': 'Left' },
        { 'Right': 'Right' }
    ],
    default: 'Center'
});

Joystick.attributes.add('free', {
    type: 'boolean',
    default: false
});

Joystick.attributes.add('ring', {
    type: 'boolean',
    default: false
});

Joystick.attributes.add('animShow', {
    type: 'json',
    schema: [{
        name: 'time',
        type: 'number', 
        default: 1.0 
    }, {
        name: 'playOnStart',
        type: 'boolean',
        default: true
    }, {
        name: 'ended',
        type: 'boolean',
        default: false
    }, {
        name: 'sclParent',
        type: 'curve',
        curves: [ 'x' ],
        default: {
            keys: [
                [0, 0],
                [1, 1]
            ]
        }
    }, {
        name: 'sclStick',
        type: 'curve',
        curves: [ 'x' ],
        default: {
            keys: [
                [0, 0],
                [1, 1]
            ]
        }
    }]
});


Joystick.prototype.initialize = function () {
    if (!this.app.touch || pc.platform.desktop) {
        this.entity.parent.enabled = false;
        return;
    }

    this.uiScreen = this.app.scene.root.findByName('UI').screen;
    this.canvas = document.getElementById('application-canvas');
    // this.device = this.app.graphicsDevice;

    this.isPressed = false;
    this.ringEnabled = false;
    if (this.ring) {
        this.ringTimeout = 0.0;
        this.ringElement = this.entity.parent.findByName('Ring');
    }

    this.vec2A = new pc.Vec2();
    this.parentPosition = new pc.Vec3();
    this.parentPosition.copy(this.entity.parent.getLocalPosition());
    this.parentPositionDefault = new pc.Vec3();
    this.parentPositionDefault.copy(this.parentPosition);
    this.joystickSize = this.entity.parent.element.width / 2;
    this.resolutionCanvas = new pc.Vec2();
    this.getResolutionCanvas();
    this.scale_UItoCanvas = this.getScale_UItoCanvas_Log();
    // this.resolutionRT = new pc.Vec2();
    // this.resolutionRT.set(this.app.graphicsDevice.width, this.app.graphicsDevice.height);
    // this.scale_UItoRT = this.getScale_UItoRT();
    // this.scale_RTtoCanvas = this.getScale_RTtoCanvas();
    // this.scale_UItoRTtoCanvas = this.scale_UItoRT * this.scale_RTtoCanvas;

    this.app.on('resolutionSwitcher:resize', () => {
        this.getResolutionCanvas();
        this.scale_UItoCanvas = this.getScale_UItoCanvas_Log();
        // this.resolutionRT.set(this.app.graphicsDevice.width, this.app.graphicsDevice.height);
        // this.scale_UItoRT = this.getScale_UItoRT();
        // this.scale_RTtoCanvas = this.getScale_RTtoCanvas();
        // this.scale_UItoRTtoCanvas = this.scale_UItoRT * this.scale_RTtoCanvas;
    });
    window.addEventListener('resize', () => {
        this.getResolutionCanvas();
        this.scale_UItoCanvas = this.getScale_UItoCanvas_Log();
        // this.resolutionRT.set(this.app.graphicsDevice.width, this.app.graphicsDevice.height);
        // this.scale_UItoRT = this.getScale_UItoRT();
        // this.scale_RTtoCanvas = this.getScale_RTtoCanvas();
        // this.scale_UItoRTtoCanvas = this.scale_UItoRT * this.scale_RTtoCanvas;
    });


    if (this.app.touch) {
        this.touchId = -1;
        this.entity.element.on(pc.EVENT_TOUCHSTART, this.onTouchStartElement, this);
        this.app.touch.on(pc.EVENT_TOUCHSTART, this.onTouchStart, this);
        this.app.touch.on(pc.EVENT_TOUCHMOVE, this.onTouchMove, this);
        this.app.touch.on(pc.EVENT_TOUCHEND, this.onTouchEnd, this);
        this.app.touch.on(pc.EVENT_TOUCHCANCEL, this.onTouchCancel, this);
    } else {
        if (this.free) {
            this.app.mouse.on(pc.EVENT_MOUSEDOWN, (event) => {
                if (!this.isPressed) {
                    let done = false;
                    if (event.y > this.resolutionCanvas.y - (this.joystickSize + this.parentPositionDefault.y) * this.scale_UItoCanvas) {
                        if (this.screenSide === 'Center') {
                            done = true;
                        } else if (this.screenSide === 'Left' && event.x < this.resolutionCanvas.x * 0.5 - this.joystickSize * this.scale_UItoCanvas) {
                            done = true;
                        } else if (this.screenSide === 'Right' && event.x > this.resolutionCanvas.x * 0.5 + this.joystickSize * this.scale_UItoCanvas) {
                            done = true;
                        }
                    }

                    if (!done)
                        return;

                    if (this.screenSide === 'Center') {
                        this.vec2A.set(
                            (event.x - this.resolutionCanvas.x * 0.5) / this.scale_UItoCanvas,
                            (this.resolutionCanvas.y - event.y) / this.scale_UItoCanvas
                        );
                    } else if (this.screenSide === 'Left' && event.x < this.resolutionCanvas.x * 0.5) {
                        this.vec2A.set(
                            event.x / this.scale_UItoCanvas,
                            (this.resolutionCanvas.y - event.y) / this.scale_UItoCanvas
                        );
                    } else if (this.screenSide === 'Right' && event.x > this.resolutionCanvas.x * 0.5) {
                        this.vec2A.set(
                            (event.x - this.resolutionCanvas.x) / this.scale_UItoCanvas,
                            (this.resolutionCanvas.y - event.y) / this.scale_UItoCanvas
                        );
                    }

                    this.entity.parent.setLocalPosition(this.vec2A.x, this.vec2A.y, 0.0);
                    this.parentPosition.copy(this.entity.parent.getLocalPosition());
                }

                this.isPressed = true;
                if (this.ring) {
                    this.ringEnabled = true;
                    this.ringTimeout = 0.0;
                }
            });
        }

        this.entity.element.on(pc.EVENT_MOUSEDOWN, (event) => {
            if (!this.isPressed && this.free) {
                if (this.screenSide === 'Center') {
                    this.vec2A.set(
                        (event.x - this.resolutionCanvas.x * 0.5) / this.scale_UItoCanvas, 
                        (this.resolutionCanvas.y - event.y) / this.scale_UItoCanvas
                    );
                } else if (this.screenSide === 'Left' && event.x < this.resolutionCanvas.x * 0.5) {
                    this.vec2A.set(
                        event.x / this.scale_UItoCanvas, 
                        (this.resolutionCanvas.y - event.y) / this.scale_UItoCanvas
                    );
                } else if (this.screenSide === 'Right' && event.x > this.resolutionCanvas.x * 0.5) {
                    this.vec2A.set(
                        (event.x - this.resolutionCanvas.x) / this.scale_UItoCanvas, 
                        (this.resolutionCanvas.y - event.y) / this.scale_UItoCanvas
                    );
                }

                this.entity.parent.setLocalPosition(this.vec2A.x, this.vec2A.y, 0.0);
                this.parentPosition.copy(this.entity.parent.getLocalPosition());
            }

            this.isPressed = true;
            if (this.ring) {
                this.ringEnabled = true;
                this.ringTimeout = 0.0;
            }
        });

        this.app.mouse.on(pc.EVENT_MOUSEUP, (event) => {
            if (this.isPressed) {
                this.isPressed = false;
                this.entity.setLocalPosition(0.0, 0.0, 0.0);
                if (this.free) {
                    this.entity.parent.setLocalPosition(this.parentPositionDefault);
                    this.parentPosition.copy(this.parentPositionDefault);
                }

                let x = 0.0;
                let y = 0.0;

                if (this.ring) {
                    this.ringTimeout = 1.0;
                    if (this.ringEnabled) {
                        if (this.screenSide === 'Center') {
                            this.vec2A.set(
                                ((event.x - this.resolutionCanvas.x * 0.5) / this.scale_UItoCanvas) - this.parentPosition.x,
                                ((this.resolutionCanvas.y - event.y) / this.scale_UItoCanvas) - this.parentPosition.y
                            );
                        } else if (this.screenSide === 'Left' && event.x < this.resolutionCanvas.x * 0.5) {
                            this.vec2A.set(
                                (event.x / this.scale_UItoCanvas) - this.parentPosition.x,
                                ((this.resolutionCanvas.y - event.y) / this.scale_UItoCanvas) - this.parentPosition.y
                            );
                        } else if (this.screenSide === 'Right' && event.x > this.resolutionCanvas.x * 0.5) {
                            this.vec2A.set(
                                ((event.x - this.resolutionCanvas.x) / this.scale_UItoCanvas) - this.parentPosition.x,
                                ((this.resolutionCanvas.y - event.y) / this.scale_UItoCanvas) - this.parentPosition.y
                            );
                        }

                        if (this.vec2A.length() > this.joystickSize) {
                            this.vec2A.normalize().mulScalar(this.joystickSize);
                        }

                        x = this.vec2A.x / this.joystickSize;
                        y = this.vec2A.y / this.joystickSize;
                    }
                }

                this.app.fire('joystickControl:isPressed', { name: this.name, ring: this.ringEnabled, isPressed: false, x: x, y: y });
            }
        });

        this.app.mouse.on(pc.EVENT_MOUSEMOVE, (event) => {
            console.log('event: ', event);

            if (this.isPressed) {
                this.app.mouse.disablePointerLock();

                if (this.screenSide === 'Center') {
                    this.vec2A.set(
                        ((event.x - this.resolutionCanvas.x * 0.5) / this.scale_UItoCanvas) - this.parentPosition.x,
                        ((this.resolutionCanvas.y - event.y) / this.scale_UItoCanvas) - this.parentPosition.y
                    );
                } else if (this.screenSide === 'Left' && event.x < this.resolutionCanvas.x * 0.5) {
                    this.vec2A.set(
                        (event.x / this.scale_UItoCanvas) - this.parentPosition.x,
                        ((this.resolutionCanvas.y - event.y) / this.scale_UItoCanvas) - this.parentPosition.y
                    );
                } else if (this.screenSide === 'Right' && event.x > this.resolutionCanvas.x * 0.5) {
                    this.vec2A.set(
                        ((event.x - this.resolutionCanvas.x) / this.scale_UItoCanvas) - this.parentPosition.x,
                        ((this.resolutionCanvas.y - event.y) / this.scale_UItoCanvas) - this.parentPosition.y
                    );
                }

                if (this.vec2A.length() > this.joystickSize) {
                    // this.ringEnabled = true;
                    // this.ringTimeout = 0.0;
                    this.vec2A.normalize().mulScalar(this.joystickSize);
                }
                this.entity.setLocalPosition(this.vec2A.x, this.vec2A.y, 0.0);

                const x = this.vec2A.x / this.joystickSize;
                const y = this.vec2A.y / this.joystickSize;
                this.app.fire('joystickControl:isPressed', { name: this.name, ring: false, isPressed: true, x: x, y: y });
            }
        });
    }


    this.sclParent = this.entity.parent.element.width;
    this.sclStick = this.entity.element.width;
    if (this.ringElement)
        this.sclRing = this.ringElement.element.width;

    this.animTime = 0.0;
    if (!this.animShow.ended && this.animShow.playOnStart) {
        const t = 0.0;
        const sclParent = this.animShow.sclParent.value(t);
        this.entity.parent.element.width = this.sclParent*sclParent;
        this.entity.parent.element.height = this.sclParent*sclParent;

        if (this.ringElement) {
            this.ringElement.element.width = 298*sclParent;
            this.ringElement.element.height = 298*sclParent;
        }

        const sclStick = this.animShow.sclStick.value(t);
        this.entity.element.width = this.sclStick*sclStick;
        this.entity.element.height = this.sclStick*sclStick;
    }
    // this.animShow.playOnStart = false;

    // this.app.once('inputForm:setUsername', () => {
        this.animShow.playOnStart = true;
    // });
};


Joystick.prototype.update = function (dt) {
    if (!this.animShow.ended && this.animShow.playOnStart) {
        this.animTime += dt;
        let t = this.animTime / this.animShow.time;
        if (t > 1.0) {
            t = 1.0;
            this.animShow.ended = true;
        }

        const sclParent = this.animShow.sclParent.value(t);
        this.entity.parent.element.width = this.sclParent*sclParent;
        this.entity.parent.element.height = this.sclParent*sclParent;

        if (this.ringElement) {
            this.ringElement.element.width = 298*sclParent;
            this.ringElement.element.height = 298*sclParent;
        }

        const sclStick = this.animShow.sclStick.value(t);
        this.entity.element.width = this.sclStick*sclStick;
        this.entity.element.height = this.sclStick*sclStick;
    }

    if (!this.ring)
        return;

    if (!this.ringEnabled)
        return;

    this.ringTimeout += dt;
    if (this.ringTimeout >= 0.25) {
        this.ringEnabled = false;
        if (this.ringElement) 
            this.ringElement.enabled = false;
    } else {
        if (this.ringElement) {
            if (!this.ringElement.enabled)
                this.ringElement.enabled = true;
        }
    }
};


Joystick.prototype.getResolutionCanvas = function () {
    const width = this.canvas.style.width;
    const height = this.canvas.style.height;
    this.resolutionCanvas.set(parseInt(width.slice(0, -2)), parseInt(height.slice(0, -2)));
};


// Joystick.prototype.getScaleFactor = function () {
//     const width = this.canvas.style.width;
//     const height = this.canvas.style.height;
//     const resolution = [parseInt(width.slice(0, -2)), parseInt(height.slice(0, -2))];
//     const scaleFactor = ((this.device.width / resolution[0]) + (this.device.height / resolution[1])) * 0.5;
//     return scaleFactor;
// };


// Joystick.prototype.getScale_UItoRT = function () {
//     if (this.resolutionRT.x > this.resolutionRT.y) {
//         const scale1 = this.resolutionRT.x / 1280;
//         const scale2 = this.resolutionRT.y / 720;
//         return (scale1 + scale2) / 2;
//     } else {
//         const scale1 = this.resolutionRT.y / 1280;
//         const scale2 = this.resolutionRT.x / 720;
//         return (scale1 + scale2) / 2;
//     }
// };


// Joystick.prototype.getScale_RTtoCanvas = function () {
//     return this.resolutionCanvas.x / this.resolutionRT.x;
// };


Joystick.prototype.getScale_UItoCanvas_Log = function () {
    const lx = Math.log2((this.resolutionCanvas.x || 1) / this.uiScreen.referenceResolution.x);
    const ly = Math.log2((this.resolutionCanvas.y || 1) / this.uiScreen.referenceResolution.y);
    return Math.pow(2, (lx * (1 - this.uiScreen.scaleBlend) + ly * this.uiScreen.scaleBlend));
};


Joystick.prototype.getTouch = function (touches, touchId) {
    for (let i = 0; i < touches.length; i++) {
        const touch = touches[i];
        if (touch.id === touchId)
            return touch;
    }

    return null;
};


Joystick.prototype.onTouchStartElement = function (evt) {
    if (this.isPressed)
        return;

    this.touchId = evt.changedTouches[0].identifier;
    this.isPressed = true;
    if (this.ring) {
        this.ringEnabled = true;
        this.ringTimeout = 0.0;
    }
};


Joystick.prototype.onTouchStart = function (evt) {
    if (this.isPressed)
        return;

    if (!this.free)
        return;

    const touchId = evt.changedTouches[0].id;
    const touch = this.getTouch(evt.changedTouches, touchId);
    if (!touch)
        return;

    let done = false;
    if (touch.y > this.resolutionCanvas.y - (this.joystickSize + this.parentPositionDefault.y) * this.scale_UItoCanvas) {
        if (this.screenSide === 'Center') {
            this.vec2A.set(
                (touch.x - this.resolutionCanvas.x * 0.5) / this.scale_UItoCanvas, 
                (this.resolutionCanvas.y - touch.y) / this.scale_UItoCanvas
            );
            done = true;
        } else if (this.screenSide === 'Left' && touch.x < this.resolutionCanvas.x * 0.5) {
            this.vec2A.set(
                touch.x / this.scale_UItoCanvas, 
                (this.resolutionCanvas.y - touch.y) / this.scale_UItoCanvas
            );
            done = true;
        } else if (this.screenSide === 'Right' && touch.x > this.resolutionCanvas.x * 0.5) {
            this.vec2A.set(
                (touch.x - this.resolutionCanvas.x) / this.scale_UItoCanvas, 
                (this.resolutionCanvas.y - touch.y) / this.scale_UItoCanvas
            );
            done = true;
        }
    }

    if (done) {
        this.touchId = touchId;
        this.entity.parent.setLocalPosition(this.vec2A.x, this.vec2A.y, 0.0);
        this.parentPosition.copy(this.entity.parent.getLocalPosition());
        this.isPressed = true;
        if (this.ring) {
            this.ringEnabled = true;
            this.ringTimeout = 0.0;
        }
    }
    evt.event.preventDefault();
};


Joystick.prototype.onTouchMove = function (evt) {
    if (!this.isPressed)
        return;

    const touch = this.getTouch(evt.changedTouches, this.touchId);
    if (!touch)
        return;

    if (this.screenSide === 'Center') {
        this.vec2A.set(
            ((touch.x - this.resolutionCanvas.x * 0.5) / this.scale_UItoCanvas) - this.parentPosition.x,
            ((this.resolutionCanvas.y - touch.y) / this.scale_UItoCanvas) - this.parentPosition.y
        );
    } else if (this.screenSide === 'Left') {
        this.vec2A.set(
            (touch.x / this.scale_UItoCanvas) - this.parentPosition.x,
            ((this.resolutionCanvas.y - touch.y) / this.scale_UItoCanvas) - this.parentPosition.y
        );
    } else if (this.screenSide === 'Right') {
        this.vec2A.set(
            ((touch.x - this.resolutionCanvas.x) / this.scale_UItoCanvas) - this.parentPosition.x,
            ((this.resolutionCanvas.y - touch.y) / this.scale_UItoCanvas) - this.parentPosition.y
        );
    }

    if (this.vec2A.length() > this.joystickSize) {
        // this.ringEnabled = true;
        // this.ringTimeout = 0.0;
        this.vec2A.normalize().mulScalar(this.joystickSize);
    }
    this.entity.setLocalPosition(this.vec2A.x, this.vec2A.y, 0.0);

    const x = this.vec2A.x / this.joystickSize;
    const y = this.vec2A.y / this.joystickSize;
    this.app.fire('joystickControl:isPressed', { name: this.name, ring: false, isPressed: true, x: x, y: y });
    evt.event.preventDefault();
};


Joystick.prototype.onTouchEnd = function (evt) {
    if (!this.isPressed)
        return;

    const touch = this.getTouch(evt.changedTouches, this.touchId);
    if (!touch)
        return;

    this.touchId = -1;

    this.isPressed = false;
    this.entity.setLocalPosition(0.0, 0.0, 0.0);
    if (this.free) {
        this.entity.parent.setLocalPosition(this.parentPositionDefault);
        this.parentPosition.copy(this.parentPositionDefault);
    }

    let x = 0.0;
    let y = 0.0;

    if (this.ring) {
        this.ringTimeout = 1.0;
        if (this.ringEnabled) {
            if (this.screenSide === 'Center') {
                this.vec2A.set(
                    ((touch.x - this.resolutionCanvas.x * 0.5) / this.scale_UItoCanvas) - this.parentPosition.x,
                    ((this.resolutionCanvas.y - touch.y) / this.scale_UItoCanvas) - this.parentPosition.y
                );
            } else if (this.screenSide === 'Left') {
                this.vec2A.set(
                    (touch.x / this.scale_UItoCanvas) - this.parentPosition.x,
                    ((this.resolutionCanvas.y - touch.y) / this.scale_UItoCanvas) - this.parentPosition.y
                );
            } else if (this.screenSide === 'Right') {
                this.vec2A.set(
                    ((touch.x - this.resolutionCanvas.x) / this.scale_UItoCanvas) - this.parentPosition.x,
                    ((this.resolutionCanvas.y - touch.y) / this.scale_UItoCanvas) - this.parentPosition.y
                );
            }

            if (this.vec2A.length() > this.joystickSize) {
                this.vec2A.normalize().mulScalar(this.joystickSize);
            }

            x = this.vec2A.x / this.joystickSize;
            y = this.vec2A.y / this.joystickSize;
        }
    }

    this.app.fire('joystickControl:isPressed', { name: this.name, ring: this.ringEnabled, isPressed: false, x: x, y: y });
    evt.event.preventDefault();
};


Joystick.prototype.onTouchCancel = function (evt) {
    if (!this.isPressed)
        return;

    const touch = this.getTouch(evt.changedTouches, this.touchId);
    if (!touch)
        return;

    this.touchId = -1;

    this.isPressed = false;
    this.entity.setLocalPosition(0.0, 0.0, 0.0);
    if (this.free) {
        this.entity.parent.setLocalPosition(this.parentPositionDefault);
        this.parentPosition.copy(this.parentPositionDefault);
    }

    let x = 0.0;
    let y = 0.0;

    if (this.ring) {
        this.ringTimeout = 1.0;
        if (this.ringEnabled) {
            if (this.screenSide === 'Center') {
                this.vec2A.set(
                    ((touch.x - this.resolutionCanvas.x * 0.5) / this.scale_UItoCanvas) - this.parentPosition.x,
                    ((this.resolutionCanvas.y - touch.y) / this.scale_UItoCanvas) - this.parentPosition.y
                );
            } else if (this.screenSide === 'Left') {
                this.vec2A.set(
                    (touch.x / this.scale_UItoCanvas) - this.parentPosition.x,
                    ((this.resolutionCanvas.y - touch.y) / this.scale_UItoCanvas) - this.parentPosition.y
                );
            } else if (this.screenSide === 'Right') {
                this.vec2A.set(
                    ((touch.x - this.resolutionCanvas.x) / this.scale_UItoCanvas) - this.parentPosition.x,
                    ((this.resolutionCanvas.y - touch.y) / this.scale_UItoCanvas) - this.parentPosition.y
                );
            }

            if (this.vec2A.length() > this.joystickSize) {
                this.vec2A.normalize().mulScalar(this.joystickSize);
            }

            x = this.vec2A.x / this.joystickSize;
            y = this.vec2A.y / this.joystickSize;
        }
    }

    this.app.fire('joystickControl:isPressed', { name: this.name, ring: this.ringEnabled, isPressed: false, x: x, y: y });
    evt.event.preventDefault();
};