pc.script.createLoadingScreen(function (app) {
    const bgImageUrl = 'https://cdn.xsolla.net/cloud-gaming-bucket-prod/87825ff1-948f-44ed-beaf-a56217b986af.png';
    const appTitle = '80lv Metasites Template';


    // #region //////////////////////// Network ////////////////////////
    app.player = new Player(app);
    app.gameRoom = new GameRoom(app);
    app.photonLoadBalancing = new PhotonLoadBalancing(app);
    // #endregion


    // #region //////////////////////// AFK ////////////////////////
    app.userAFK = false;
    document.addEventListener("visibilitychange", function () {
        if (document.hidden) {
            app.userAFK = true;
            console.log('UserAFK true');
        } else {
            app.userAFK = false;
            console.log('UserAFK false');
        }
    });

    window.onfocus = function () {
        app.userAFK = false;
        console.log('UserAFK false');
    }

    window.onblur = function () {
        app.userAFK = true;
        console.log('UserAFK true');
    }
    // #endregion


    const showLoader = function () {
        // splash wrapper
        const wrapper = document.createElement('div');
        wrapper.id = 'application_loading_wrapper';
        document.body.appendChild(wrapper);

        this.title = document.createElement('span');
        this.title.id = 'app_title';
        this.title.innerText = appTitle;

        this.loadStatus = document.createElement('span');
        this.loadStatus.id = 'app_load_status';

        this.loadStatus.innerText = 'Starting the game.';

        this.animationWrapper = document.createElement('div');
        this.animationWrapper.id = 'animation_wrapper';

        wrapper.appendChild(this.title);
        wrapper.appendChild(this.animationWrapper);
        wrapper.appendChild(this.loadStatus);

        const animationImagesSrc = [
            'https://cdn.xsolla.net/cloud-gaming-bucket-prod/cgs-assets/C9xLv4JW.png',
            'https://cdn.xsolla.net/cloud-gaming-bucket-prod/cgs-assets/D3ebOi_B.png',
            'https://cdn.xsolla.net/cloud-gaming-bucket-prod/cgs-assets/BoSUCaOm.png'
        ];

        this.animationImages = animationImagesSrc.map((imageSrc, index) => {
            const imgEl = document.createElement('img');
            imgEl.src = imageSrc;
            imgEl.id = `animation_image_${index + 1}`;

            this.animationWrapper.appendChild(imgEl);

            return imgEl;
        })

        const animationImage = document.createElement('div');
        animationImage.id = 'animation_image';
        this.animationWrapper.appendChild(animationImage);

        this.progressBarContainer = document.createElement('div');
        this.progressBarContainer.id = 'progress_bar_container';
        wrapper.appendChild(this.progressBarContainer);

        const bar = document.createElement('div');
        bar.id = 'progress_bar';
        this.progressBarContainer.appendChild(bar);

        const bgImageContainer = document.createElement('div');
        bgImageContainer.id = 'application_bg';

        const bgImage = document.createElement('img');
        bgImage.src = bgImageUrl;
        bgImageContainer.appendChild(bgImage);
        bgImage.onload = () => {
            bgImageContainer.style.opacity = 1;
            animationImage.style.opacity = 1;
        };

        wrapper.appendChild(bgImageContainer);

    };

    const hideLoader = function () {
        const splash = document.getElementById('application_loading_wrapper');
        splash.parentElement.removeChild(splash);
    };

    const setProgress = function (value) {
        const bar = document.getElementById('progress_bar');
        if (bar) {
            value = Math.min(1, Math.max(0, value));
            bar.style.width = value * 100 + '%';
        }
    };

    const createCss = function () {
        const css = [
            `body {
                background-color: #283538;
            }`,
            `#application_loading_wrapper {
                position: absolute;
                top: 0;
                left: 0;
                height: 100%;
                width: 100%;
                background-color: #283538;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                z-index: 1000;
            }`,
            `#progress_bar_container {
                margin: 20px auto 0 auto;
                height: 2px;
                width: 100%;
                max-width: 200px;
                background-color: #1d292c;
                opacity: 0;
                transition: opacity 1s ease 0s;
            }`,
            `#progress_bar {
                width: 0%;
                height: 100%;
                background-color: #f60;
            }`,
            `#app_title {
                font-size: 42px;
                line-height: 54px;
                text-align: center;
                font-weight: 800;
                text-transform: uppercase;
                color: inherit;
                display: inline-block;
                width: 100%;
                height: auto;
                margin-bottom: 0px;
                margin-top: 0px;
                color: #fff;
                animation: 1s ease 0s 1 normal none running lbWRkT;
                opacity: 0;
                pointer-events: none;
                transition: opacity 1s ease 0s;
            }`,
            `#app_load_status {
                font-size: 20px;
                line-height: 28px;
                font-weight: 500;
                text-align: center;
                color: inherit;
                display: inline-block;
                width: 100%;
                height: auto;
                margin-bottom: 0px;
                margin-top: 0px;
                color: #fff;
                animation: 1s ease 0s 1 normal none running lbWRkT;
                opacity: 0;
                pointer-events: none;
                transition: opacity 1s ease 0s;
            }`,
            `#animation_wrapper {
                display: flex;
                align-items: center;
                justify-content: center;
                flex-direction: column;
                position: relative;
                width: 50vh;
                height: 50vh;
                max-width: 300px;
                max-height: 300px;
                animation-duration: 1.2s;
                animation-fill-mode: backwards;
                animation-iteration-count: 1;
                animation-timing-function: ease;
                animation-name: none;
                opacity: 0;
                transform: scale(1);
                transition: opacity 1s ease 0s, transform 1s ease 0s;
            }`,
            `@keyframes Rotate1 {
                0% {
                    transform: rotate(0deg);
                }
                100% {
                    transform: rotate(360deg);
                }
            }`,
            `#animation_image {
                position: relative;
                z-index: 5;
                width: 50%;
                height: 50%;
                overflow: hidden;
                border-radius: 50%;
                opacity: 0;
                transition: opacity 1s ease 0s;
                background-size: cover;
                background-repeat: no-repeat;
                background-position: center center;
                background-image: url(${bgImageUrl});
            }
            
            #animation_image_1 {
                position: absolute;
                inset: 0px;
                width: 100%;
                height: 100%;
                animation-timing-function: linear;
                animation-iteration-count: infinite;
                animation-duration: 1.5s;
                z-index: 3;
                animation-name: Rotate1;
            }

            #animation_image_2 {
                position: absolute;
                inset: 0px;
                width: 100%;
                height: 100%;
                animation-timing-function: linear;
                animation-iteration-count: infinite;
                animation-duration: 2s;
                z-index: 2;
                animation-name: Rotate1;
            }

            #animation_image_3 {
                position: absolute;
                inset: 0px;
                width: 100%;
                height: 100%;
                animation-timing-function: linear;
                animation-iteration-count: infinite;
                animation-duration: 5s;
                z-index: 1;
                animation-name: Rotate1;
            }
            
            #application_bg {
                z-index: -1;
                width: 100%;
                height: 100%;
                opacity: 0;
                transition: opacity 0.5s ease-in-out 0.1s, filter 1s ease 0s;
                filter: blur(20px);
                position: absolute;
                top: 0;
                left: 0;
                background-size: cover;
                background-repeat: no-repeat;
                background-position: center center;
                background-image: url(${bgImageUrl});
            }

            #application_bg img {
                position: relative;
                z-index: 0;
                max-width: 100%;
                max-height: 100%;
                user-select: none;
                pointer-events: none;
                object-fit: cover;
                object-position: center center;
                width: 0px;
                height: 0px;
                opacity: 1;
                overflow: hidden;
                visibility: hidden;
            }  
            `
        ].join('\n');

        const style = document.createElement('style');
        style.type = 'text/css';
        if (style.styleSheet) {
            style.styleSheet.cssText = css;
        } else {
            style.appendChild(document.createTextNode(css));
        }

        document.head.appendChild(style);
    };

    const showLoadingAnimation = function () {
        const promises = this.animationImages.map(i => new Promise(resolve => i.onload = resolve));

        Promise.all(promises).then(() => {
            this.animationWrapper.style.opacity = 1;
            this.loadStatus.style.opacity = 1;
            this.title.style.opacity = 1;
            this.progressBarContainer.style.opacity = 1;
        })
    }

    createCss();
    showLoader();
    showLoadingAnimation();

    app.on('preload:end', function () {
        app.off('preload:progress');
    });
    app.on('preload:progress', setProgress);
    app.on('start', hideLoader);
});