const OnPreRender = pc.createScript('onPreRender');


OnPreRender.prototype.init = function() {
    this.onPreRender0 = null;
    this.onPreRender1 = null;
    this.onPreRender2 = null;
    this.onPreRender3 = null;

    this.entity.camera.onAppPrerender = () => {
        if (this.onPreRender0 !== null) 
            this.onPreRender0();
        
        if (this.onPreRender1 !== null) 
            this.onPreRender1();

        if (this.onPreRender2 !== null) 
            this.onPreRender2();

        if (this.onPreRender3 !== null) 
            this.onPreRender3();
    };
};
