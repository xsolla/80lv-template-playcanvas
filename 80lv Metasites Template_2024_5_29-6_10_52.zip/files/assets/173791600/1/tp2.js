var Tp2 = pc.createScript('tp2');

Tp2.prototype.initialize = function() {
    this.entity.collision.on('triggerenter', this.onTriggerEnter, this);
};

Tp2.prototype.onTriggerEnter = function(result) {
    if (result.tags.has('userSkin')) {
        // const scene = this.app.scenes.find('Scene2');
        // this.app.scenes.loadSceneHierarchy(scene);

        window.top.location.href = 'https://playcanv.as/b/07c1987d';
    }
};