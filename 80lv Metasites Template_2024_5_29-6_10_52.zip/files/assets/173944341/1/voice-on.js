var VoiceOn = pc.createScript('voiceOn');

VoiceOn.attributes.add('voice_button', { type: 'asset', assetType: 'html', title: 'HTML Asset' });
VoiceOn.attributes.add('css', { type: 'asset', assetType: 'css', title: 'CSS Asset' });
VoiceOn.attributes.add('loadingAsset', {
  type: 'asset',
  assetType: 'texture',
  title: 'My PNG Asset'
});

const getDefaultMediaStream = () => {
  return navigator.mediaDevices.getUserMedia({
    audio: {
      echoCancellation: true,
      autoGainControl: true,
      noiseSuppression: true,
      sampleRate: 48000,
    },
  });
}


let odinConnectionState = 'disconnected';
let odinPeers = new Map();
let mediaStream = null;
let muted = true;


// initialize code called once per entity
VoiceOn.prototype.initialize = function () {
  this.accessKey = Environments.odinAccessKey;
  this.roomName = Environments.roomName;

  var style = document.createElement('style');
  document.head.appendChild(style);
  style.innerHTML = this.css.resource || '';

  document.addEventListener('click', this.voiceUp.bind(this), { once: true });
  document.addEventListener('keydown', this.voiceUp.bind(this), { once: true });
  document.addEventListener('touchend', this.voiceUp.bind(this), { once: true });


  const voiceOnContainer = document.createElement('div');
  voiceOnContainer.classList.add('voice_tool');
  voiceOnContainer.innerHTML = this.voice_button.resource || '';
  voiceOnContainer.style.display = 'flex';

  this.voiceOnButton = voiceOnContainer.querySelector('#voice_button');
  this.voiceOnButton.addEventListener('click', this.onClick.bind(this));

  document.body.addEventListener('keydown', (event) => {
    if (event.code === 'KeyK' && !window._chatting) this.onClick();
  })

  this.voiceOnIcon = this.voiceOnButton.querySelector('#voice_button_on');
  this.voiceOffIcon = this.voiceOnButton.querySelector('#voice_button_off');

  const loadingImg = document.createElement('img');
  loadingImg.src = this.loadingAsset.getFileUrl();
  loadingImg.id = 'voice_button_loading';
  this.voiceOnButton.appendChild(loadingImg);

  this.voiceLoadingIcon = this.voiceOnButton.querySelector('#voice_button_loading');

  this.voiceOnIcon.style.display = 'none';
  this.voiceOffIcon.style.display = 'none';

  document.body.appendChild(voiceOnContainer);
};

const roomHandler = function (room) {
  // Handle changes of the OdinRoom connection state.
  room.addEventListener(
    'ConnectionStateChanged',
    (connectionStateChangedEvent) => {
      const state = connectionStateChangedEvent.payload.newState;
      odinConnectionState = state;
      console.log('connectionState', odinConnectionState);
    }
  );

  // Handle peers joining the room.
  room.addEventListener('PeerJoined', (peerJoinedEvent) => {
    const peer = peerJoinedEvent.payload.peer;
    odinPeers.set(peer.id, peer);
  });

  // Handle peers leaving the room.
  room.addEventListener('PeerLeft', (peerLeftEvent) => {
    const peer = peerLeftEvent.payload.peer;
    odinPeers.delete(peer.id);
    console.log('peers', odinPeers);
  });

  // Handle medias in the room getting started.
  room.addEventListener('MediaStarted', (mediaStartedEvent) => {
    // Start the media to either be able to talk (on own media) or to listen (on remote media).
    mediaStartedEvent.payload.media.start().then();
  });

  // Handle medias in the room getting started.
  room.addEventListener('MediaStopped', (mediaStoppedEvent) => {
    // Stop the Media to either stop sending voice data (on own media) or to mute others (on remote media).
    mediaStoppedEvent.payload.media.stop().then();
  });
}

VoiceOn.prototype.onClick = function () {
  this.app.mouse.disablePointerLock();

  if (muted) {
    this.unmute();
  } else {
    this.mute();
  }
}

VoiceOn.prototype.voiceUp = async function () {
  // this.app.mouse.disablePointerLock();
  if (odinConnectionState === 'connecting') return;

  if (odinConnectionState !== 'disconnected') {
    this.disconnect();
    return;
  }

  const { OdinClient,
    OdinConnectionState,
    OdinPeer,
    OdinRoom,
    valueToUint8Array } = ODIN;

  const { TokenGenerator } = odinTokens || window.odinTokens;

  if (!this.accessKey) {
    throw new Error('Please provide an access key!');
  }

  // Generate a token using the specified access key.
  const tokenGenerator = new TokenGenerator(this.accessKey);
  const token = tokenGenerator.createToken(this.roomName, 'test' + Math.random() * 100000);

  const room = await OdinClient.initRoom(token);

  roomHandler.bind(this)(room);

  const userData = valueToUint8Array('test-name');
  await room.join(userData);

  mediaStream = await getDefaultMediaStream();
  room.createMedia(mediaStream);

  this.voiceOffIcon.style.display = 'flex';
  this.voiceLoadingIcon.style.display = 'none';

  this.mute();
};

VoiceOn.prototype.mute = function () {
  if (mediaStream && mediaStream.getAudioTracks().length > 0) {
    mediaStream.getAudioTracks()[0].enabled = false;

    this.voiceOnIcon.style.display = 'none';
    this.voiceOffIcon.style.display = 'flex';
    this.voiceOnButton.style.backgroundColor = 'rgba(6, 7, 34, 0.64)';

    muted = true;
  }
};

VoiceOn.prototype.unmute = function () {
  if (mediaStream && mediaStream.getAudioTracks().length > 0) {
    mediaStream.getAudioTracks()[0].enabled = true;

    this.voiceOnIcon.style.display = 'flex';
    this.voiceOffIcon.style.display = 'none';
    this.voiceOnButton.style.backgroundColor = 'rgba(234, 235, 255, 1)';

    muted = false;
  }
};

VoiceOn.prototype.disconnect = function () {
  const { OdinClient } = ODIN;
  OdinClient.disconnect();

  odinPeers = new Map();
  odinConnectionState = 'disconnected';
}