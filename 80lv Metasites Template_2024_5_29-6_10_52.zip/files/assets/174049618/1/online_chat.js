var OnlineChat = pc.createScript('online_chat');

OnlineChat.attributes.add('css', { type: 'asset', assetType: 'css', title: 'CSS Asset' });
OnlineChat.attributes.add('html', { type: 'asset', assetType: 'html', title: 'HTML Asset' });
OnlineChat.attributes.add('chat_button', { type: 'asset', assetType: 'html', title: 'HTML Asset' });

OnlineChat.attributes.add("photonEntity", { type: "entity" });

OnlineChat.prototype.initialize = function () {
    this.chat = this.photonEntity.script.PhotonChatPlayCanvas.chat;
    this.roomName = this.photonEntity.script.PhotonChatPlayCanvas.roomName;
    this.app.on("ui:chat:render", this.renderMessages, this);

    // add chat styles
    var style = document.createElement('style');
    document.head.appendChild(style);
    style.innerHTML = this.css.resource || '';


    // add chat html
    this.div = document.createElement('div');
    this.div.classList.add('chat');
    this.div.innerHTML = this.html.resource || '';
    document.body.appendChild(this.div);

    this.chatElement = document.querySelector('.chat');
    this.messagesElement = document.querySelector('.chat_messages');
    this.inputElement = document.querySelector('.chat_input');

    this.inputElement.addEventListener('focus', () => window._chatting = true);
    this.inputElement.addEventListener('blur', () => window._chatting = false);

    // add chat open toggler
    const chatTool = document.createElement('div');
    chatTool.classList.add('chat_tool');
    chatTool.innerHTML = this.chat_button.resource || '';
    document.body.appendChild(chatTool);
    this.toggler = chatTool.querySelector('#chat_button');

    this.chatOnIcon = this.toggler.querySelector('#online_chat_on');
    this.chatOffIcon = this.toggler.querySelector('#online_chat_off');

    this.chatOnIcon.style.display = 'none';

    this.toggler.addEventListener('click', this.onClick.bind(this));

    window.addEventListener('keydown', this.onKeyDown.bind(this));

    document.body.querySelector('.send_button').addEventListener('click', () => {
        if (this.inputElement.value) {
            this.chat.publishMessage(this.roomName, this.inputElement.value);

            this.inputElement.value = '';
        }
    });
};

OnlineChat.prototype.renderMessages = function (messages) {
    const userId = this.chat.getUserId();

    for (const message of messages) {
        const div = document.createElement('div');
        div.classList.add('message');
        div.innerHTML = `<strong ${message.sender === userId ? 'class="chat_mine"' : ''}>${message.sender}</strong>: ${message.content}`;

        this.messagesElement.appendChild(div);
    }


    this.messagesElement.scrollTop = this.messagesElement.scrollHeight;
};

OnlineChat.prototype.onKeyDown = function (event) {
    if (event.key === 'Enter') {
        if (this.inputElement.value) {

            this.chat.publishMessage(this.roomName, this.inputElement.value);

            this.inputElement.value = '';
        }
    }

    if (event.code === 'KeyG' && !window._chatting) {
        this.onClick();
    }

    if (event.code === 'Slash' && !window._chatting && this.chatElement.style.display) {
        event.preventDefault();
        this.inputElement.focus();
    }
};

OnlineChat.prototype.onClick = function () {
    this.chatElement.style.display = !this.chatElement.style.display ? 'flex' : '';
    this.toggler.style.backgroundColor = !this.chatElement.style.display ? 'rgba(6, 7, 34, 0.64)' : 'rgba(234, 235, 255, 1)';

    this.messagesElement.scrollTop = this.messagesElement.scrollHeight;

    if (!this.chatElement.style.display) {
        this.chatOnIcon.style.display = 'none';
        this.chatOffIcon.style.display = 'flex';
    } else {
        this.chatOnIcon.style.display = 'flex';
        this.chatOffIcon.style.display = 'none';
    }
}