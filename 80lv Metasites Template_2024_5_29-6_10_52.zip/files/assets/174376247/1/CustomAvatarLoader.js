var CustomAvatarLoader = pc.createScript('customAvatarLoader');

CustomAvatarLoader.attributes.add('css', { type: 'asset', assetType: 'css', title: 'CSS Asset' });
CustomAvatarLoader.attributes.add('html', { type: 'asset', assetType: 'html', title: 'HTML Asset' });
CustomAvatarLoader.attributes.add("LoadingScreen", { type: "entity" });

CustomAvatarLoader.instance = null;

window.addEventListener("message", function (event) {
    if (event.origin === "https://test-6ghstz.readyplayer.me") {
        CustomAvatarLoader.instance.LoadNewAvatar(event.data);
    }

}, false);

// initialize code called once per entity
CustomAvatarLoader.prototype.initialize = function () {
    CustomAvatarLoader.instance = this;
    this.GlbURL = null;
    this.iframeWidth = window.innerWidth;
    this.iframeHeight = window.innerHeight;
    this.app.on("BtnManager:LoadAvatarButtonClick", this.customAvatarSelection.bind(this));

    this.on('destroy', function () {
        this.app.off("BtnManager:LoadAvatarButtonClick", this.customAvatarSelection.bind(this));
    }.bind(this));

    this.setupIframe();
    this.isMobile = false;

    if (pc.platform.mobile || pc.platform.android || pc.platform.ios) { // Mobile
        let avatarIframe = document.getElementById("avatarIframe");
        avatarIframe.style.width = this.iframeWidth + "px";
        avatarIframe.style.height = this.iframeHeight - 48 + "px";
        avatarIframe.style.border = "none";
        this.div.classList.add('avatar_mobile');
        this.isMobile = true;
    } else { // Desktop
        let avatarIframe = document.getElementById("avatarIframe");
        avatarIframe.style.width = "900px";
        avatarIframe.style.height = "650px";
        avatarIframe.style.border = "none";
        this.isMobile = false;
    }
};

CustomAvatarLoader.prototype.LoadNewAvatar = function (data) {
    this.CloseIframe();
    this.loadGLBModelFromURL(data);
};

CustomAvatarLoader.prototype.CloseIframe = function () {
    let iframe = document.getElementById('avatarIframe');
    let avatarDiv = document.getElementById('avatarDiv');
    iframe.style.display = "none";
    avatarDiv.style.display = "none";
    document.querySelector('.character').style.display = 'flex';
}

CustomAvatarLoader.prototype.loadGLBModelFromURL = function (modelURL) {
    var self = this;
    this.GlbURL = modelURL;
    this.app.fire("LoadingMenu:SetLoading", true, "Loading Avatar..");
    let name = "model_" + (Math.floor(Math.random() * 10000));
    let cacheURL = modelURL + "?cacheBuster=" + (Math.floor(Math.random() * 10000));

    this.LoadingScreen.enabled = true;
    utils.loadGlbContainerFromUrl(cacheURL, null, name, function (err, asset) {
        if (asset.resources[0].model) {
            const avatar = this.app.player.user.entity.findByName('PlayerModel');
            this.app.player.userSkinUrl = cacheURL;

            const renderRootEntity = asset.resource.instantiateRenderEntity();
            if (avatar) {
                const oldAvatar = avatar.children[avatar.children.length - 1];

                avatar.addChild(renderRootEntity);
                avatar.anim.rootBone = renderRootEntity;
                avatar.anim.activate = true;
                avatar.anim.reset();
                avatar.setLocalEulerAngles(180, 0, 180);
                oldAvatar.destroy();
            }
            
        } else {
            console.log(asset.resources);
        }


        this.LoadingScreen.enabled = false;
    }.bind(this));
};

CustomAvatarLoader.prototype.setupIframe = function () {
    // create STYLE element
    var style = document.createElement('style');

    // append to head
    document.head.appendChild(style);
    style.innerHTML = this.css.resource || '';

    // Add the HTML
    this.div = document.createElement('div');
    this.div.id = "avatarDiv";
    this.div.classList.add('avatarContrainer');
    

    const avatarWrapper = document.createElement('div');
    avatarWrapper.classList.add('avatarWrapper');
    avatarWrapper.innerHTML = this.html.resource || '';
    this.div.appendChild(avatarWrapper);

    const closeButton = document.createElement('button');
    closeButton.classList.add('close_iframe');
    closeButton.innerHTML = `
        <svg
            width="20"
            height="20"
            viewBox="0 0 20 20"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
        >
            <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M3.57709 4.75657C3.25165 4.43114 3.25165 3.9035 3.57709 3.57806C3.90252 3.25263 4.43016 3.25263 4.7556 3.57806L9.99967 8.82214L15.2438 3.57806C15.5692 3.25263 16.0968 3.25263 16.4223 3.57806C16.7477 3.9035 16.7477 4.43114 16.4223 4.75657L11.1782 10.0006L16.4223 15.2447C16.7477 15.5702 16.7477 16.0978 16.4223 16.4232C16.0968 16.7487 15.5692 16.7487 15.2438 16.4232L9.99967 11.1792L4.7556 16.4232C4.43016 16.7487 3.90252 16.7487 3.57709 16.4232C3.25165 16.0978 3.25165 15.5702 3.57709 15.2447L8.82116 10.0006L3.57709 4.75657Z"
                fill="#110945"
            />
        </svg>
    `;

    closeButton.addEventListener('click', this.CloseIframe.bind(this));

    avatarWrapper.appendChild(closeButton);

    this.div.style.display = "none";
    // append to body
    // can be appended somewhere else
    // it is recommended to have some container element
    // to prevent iOS problems of overfloating elements off the screen
    var canvas = document.getElementById("application-canvas");
    // canvas.style.pointerEvents = "none";
    //document.body.insertBefore(this.div,canvas);
    this.div.style.zIndex = '10000';

    document.body.appendChild(this.div);
};

CustomAvatarLoader.prototype.customAvatarSelection = function () {
    document.querySelector('.character').style.display = 'none';

    let iframe = document.getElementById('avatarIframe');
    let avatarDiv = document.getElementById('avatarDiv');

    iframe.src = 'https://test-6ghstz.readyplayer.me/avatar'; // Change this to your custom subdomain
    iframe.style.display = "block";
    avatarDiv.style.display = "flex";
};

// update code called every frame
CustomAvatarLoader.prototype.update = function (dt) {

};