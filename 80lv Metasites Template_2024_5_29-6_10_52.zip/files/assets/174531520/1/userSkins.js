const UserSkins = pc.createScript('userSkins');

UserSkins.attributes.add('materialAsset', {
    type: 'asset',
    assetType: 'material'
});


UserSkins.prototype.init = function() {
    const layerWorld = this.app.scene.layers.getLayerByName('World').id;
    const batchGroup = this.app.batcher.addGroup('Users', true, 100);
    batchGroup.layers = [layerWorld];
    this.batchGroupId = batchGroup.id;

    this.diffusePS = this.app.assets.find('users_diffusePS.glsl', 'shader').resource;
    this.transformVSBatch = this.app.assets.find('users_transformVS_Batch.glsl', 'shader').resource;

    this.material = this.materialAsset.resource;
    this.material.chunks.diffusePS = this.diffusePS;
    this.material.chunks.transformVS = this.app.assets.find('users_transformVS.glsl', 'shader').resource;
    this.material.chunks.APIVersion = pc.CHUNKAPI_1_65;
    this.material.update();

    CoreScript.mainCamera.script.onPreRender.onPreRender2 = () => {
        if (!this.recreateBatch())
            return;

        this.patchBatchMaterial();
    }
};


UserSkins.prototype.recreateBatch = function() {
    if (this.app.batcher._dirtyGroups.length <= 0)
        return false;

    for (let i = 0; i < this.app.batcher._dirtyGroups.length; i++) {
        if (this.app.batcher._dirtyGroups[i] !== this.batchGroupId)
            continue;

        this.app.batcher.generate([this.app.batcher._dirtyGroups[i]]);
        return true;
    }
    return false;
};


UserSkins.prototype.patchBatchMaterial = function() {
    for (let i = 0; i < this.app.batcher._batchList.length; i++) {
        const batch = this.app.batcher._batchList[i];
        if (batch.batchGroupId !== this.batchGroupId) 
            continue;

        batch.meshInstance._material.chunks.transformVS = this.transformVSBatch;
        batch.meshInstance._material.update();
    }
};


UserSkins.prototype.applySkin = function(skinId, skinParts) {
    for (let i = 0; i < skinParts.length; i++) {
        const skinPart = skinParts[i];

        const uvs1 = [];
        for (let i = 0; i < 24; i++) {
            uvs1.push(skinId);
            uvs1.push(0);
        }

        this.cloneMesh(skinPart, uvs1);
        skinPart.render.meshInstances[0].material = this.material;
        skinPart.render.batchGroupId = this.batchGroupId;
    }

    this.app.batcher.markGroupDirty(this.batchGroupId);
};


UserSkins.prototype.cloneMesh = function(entity, uvs1) {
    const render = entity.render;
    for (const meshInstance of render.meshInstances) {
        const colors = [];
        const indices = [];
        const normals = [];
        const positions = [];
        const uvs0 = [];
        // const uvs1 = [];

        const _mesh = meshInstance.mesh;
        _mesh.getColors(colors);
        for (let i = 0; i < colors.length; i++) {
            colors[i] = colors[i]/255;
        }
        _mesh.getIndices(indices);
        _mesh.getNormals(normals);
        _mesh.getPositions(positions);
        _mesh.getUvs(0, uvs0);
        // _mesh.getUvs(1, uvs1);


        const mesh = new pc.Mesh(this.app.graphicsDevice);
        mesh.setColors(colors);
        mesh.setIndices(indices);
        mesh.setNormals(normals);
        mesh.setPositions(positions);
        mesh.setUvs(0, uvs0);
        mesh.setUvs(1, uvs1);
        mesh.update();

        meshInstance.mesh = mesh;
    }
};
