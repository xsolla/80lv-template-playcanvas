var SoundCloud = pc.createScript('soundCloud');

SoundCloud.attributes.add('css', { type: 'asset', assetType: 'css', title: 'CSS Asset' });
SoundCloud.attributes.add('html', { type: 'asset', assetType: 'html', title: 'HTML Asset' });

SoundCloud.prototype.initialize = function() {
    const style = document.createElement('style');
    document.head.appendChild(style);
    style.innerHTML = this.css.resource || '';

    const scContainer = document.createElement('div');
    scContainer.classList.add('sound_cloud_container');
    scContainer.innerHTML = this.html.resource || '';

    const scIframe = document.createElement('iframe');
    scIframe.width = '100%'
    scIframe.height = '166';
    scIframe.scrolling = 'no';
    scIframe.src = 'https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/293&amp;auto_play=true&amp;color=%23ff5500&amp;buying=false&amp;sharing=false&amp;download=false&amp;show_artwork=false&amp;show_playcount=false&amp;show_user=false&amp;start_track=0&amp;single_active=false';
    scIframe.frameBorder = 'no';
    scIframe.allow = 'autoplay';

    scContainer.appendChild(scIframe);

    const scButton = document.createElement('div');
    scButton.classList.add('sound_cloud_button');
    const openScFrameButton = document.createElement('button');
    openScFrameButton.innerText = 'SoundCloud';
    scButton.appendChild(openScFrameButton);

    document.body.appendChild(scContainer);
    document.body.appendChild(scButton);

    scButton.addEventListener('click', () => {
        scContainer.style.display = scContainer.style.display ? '' : 'flex';
    })

    document.querySelector('#close_sound_cloud').addEventListener('click', () => {
        scContainer.style.display = '';
    })

    this.SCWidget = window.SC.Widget(scIframe);
};