var SpotifyAPI = pc.createScript('spotifyAPI');

SpotifyAPI.prototype.initialize = function () {
    const {
        spotifyClientId: clientId,
        spotifyClientSecret: clientSecret
    } = Environments;

    this.getTokenAuthHeader = 'Basic ' + btoa(clientId + ':' + clientSecret);
    this.getTokenBody = new URLSearchParams;
    this.getTokenBody.append('grant_type', 'client_credentials');
    this.authorize();

    console.log('IZIAISDIASDIASISADISIDAIASDIIOI', this.entity)
}

SpotifyAPI.prototype.authorize = async function () {
    const res = await fetch('https://accounts.spotify.com/api/token', {
        method: 'POST',
        headers: {
            'Authorization': this.getTokenAuthHeader,
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: this.getTokenBody
    })

    const { access_token, expires_in } = await res.json();

    this.authToken = access_token;
}

SpotifyAPI.prototype.findTracks = function (searchInput) {
    const encodedQ = encodeURIComponent(searchInput);
    const url = `https://api.spotify.com/v1/search?q=${encodedQ}&type=track&limit=5&offset=0&include_external=audio`;

    return this.makeRequest(url);
}

SpotifyAPI.prototype.makeRequest = async function (url, options, count) {
    let _count = count ?? 0;

    if (count > 2) throw new Error('Something went wrong with spotify client!')

    options = options || {};
    options.headers = options.headers || {};
    options.headers['Authorization'] = 'Bearer ' + this.authToken;

    const response = await fetch(url, options);
    if (response.status === 401) {
        return this.authorize().then(() => this.makeRequest(url, options, _count++));
    } else {
        return response.json();
    }
}