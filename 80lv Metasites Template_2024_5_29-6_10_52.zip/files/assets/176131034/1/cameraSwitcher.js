var CameraSwitcher = pc.createScript('cameraSwitcher');

CameraSwitcher.prototype.initialize = function() {
    this.app.keyboard.on(pc.EVENT_KEYDOWN, this.onKeyDown, this);
    this.cameraScripts = {
        'FPC': this.entity.script.firstPersonCamera,
        'TPC': this.entity.script.thirdPersonCamera,
        'TDC': this.entity.script.topDownCamera
    };

    this.currentMode = 'TPC';

    const savedCamera = window.localStorage.getItem('cameraMode');

    if (savedCamera && this.cameraScripts[savedCamera]) {
        this.switchCameraScript(savedCamera);
    }
};

CameraSwitcher.prototype.onKeyDown = function (event) {
    if (event.key === pc.KEY_V && !window._chatting) {
        switch(this.currentMode) {
            case 'TPC': {
                this.switchCameraScript('FPC');
                break;
            }
            case 'FPC': {
                this.switchCameraScript('TDC');
                break;
            }
            case 'TDC': {
                this.switchCameraScript('TPC');
                break;
            }
        }
    }
};

CameraSwitcher.prototype.switchCameraScript = function(mode) {
    for (const key in this.cameraScripts) {
        this.cameraScripts[key].enabled = key === mode;
    }

    window.localStorage.setItem('cameraMode', mode);
    this.currentMode = mode;
};