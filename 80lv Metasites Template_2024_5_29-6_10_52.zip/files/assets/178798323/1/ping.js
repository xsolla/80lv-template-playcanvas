var Ping = pc.createScript('ping');

// initialize code called once per entity
Ping.prototype.initialize = function() {
    const pingDisplay = document.createElement('div');
    pingDisplay.style.position = 'absolute';
    pingDisplay.style.top = pc.platform.mobile ? '135px' : '92px';
    pingDisplay.style.left = pc.platform.mobile ? '16px' : '28px';
    pingDisplay.style.color = '#fff';
    document.body.appendChild(pingDisplay);

    pingDisplay.innerHTML = `
        <div class="ping_title">Ping</div>
    `;

    this.pingEl = document.createElement('div');

    this.pingEl.classList.add('ping_number');

    pingDisplay.appendChild(this.pingEl);
    
    this.actor = this.app.photonClient.myActor();

    setInterval(function () {
        this.pingEl.textContent = this.app.photonClient.getRtt(this.actor);
    }.bind(this), 1000);
};