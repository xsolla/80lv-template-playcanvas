class Player {
    constructor(app) {
        this.app = app;

        this.user = null;
        this.userSkin = null;
        this.name = '';
        this.userSkinUrl = undefined;
        this.position = new pc.Vec3(0, 0, 0);

        this.app.on("photonClient:raiseEvent", this.updateState, this);
        this.app.once('users:isInitialized', () => {
            this.user = this.app.selfUser.script.user;
            this.userSkin = this.app.selfUser.script.userSkin;
            this.position = this.user.entity.getPosition().clone();

            this.fps = this.app.scene.root.script.fps;
        });

        this.timeout = 0.0;
        this.sended = false;
        this.vecLookAt = new pc.Vec3();
    }


    postUpdate(dt) {
        if (this.app.root.findByName('CameraState').script.cameraSwitcher.currentMode !== 'TDC') {
            var cameraForward = this.app.root.findByName('MainCamera').forward;
            cameraForward.y = 0;
            this.vecLookAt.copy(this.user.entity.getPosition()).add(cameraForward);

            this.user.entity.lookAt(this.vecLookAt);
        }

        const currentAngle = this.calculateYAxisAngle();

        if (
            this.userSkinUrl !== this.userSkin.userSkinUrl ||
            currentAngle !== this.angle ||
            !this.position.equals(this.user.currentPosition) ||
            !this.sended
        ) {

            this.sended = false;
            this.updateState();
        }

        if (this.timeout > 0.0)
            this.timeout -= dt;
    }

    updateState() {
        if (this.user === null)
            return;

        const data = {};

        // data.fps = Math.round(this.fps.fpsMeter.fps);
        // CoreScript.usersInfo.setFps(this.user.userId, data.fps);

        const actor = this.app.photonClient.myActor();
        data.ping = this.app.photonClient.getRtt(actor);
        CoreScript.usersInfo.setPing(this.user.userId, data.ping);

        this.name = this.app.selfUserInfo.name.element.text;
        data.name = actor.userId.slice(0, 5);
        data.photonUserId = actor.userId;

        // if (this.skinIds !== undefined && this.userSkin.currentSkin !== undefined) {
        //     data.skinIds = [];
        //     for (let i = 0; i < 6; i++) {
        //         this.skinIds[i] = this.userSkin.currentSkin[i];
        //         data.skinIds.push(this.skinIds[i]);
        //     }
        // }


        // data.s = this.app.player.user.entity.findByName('PlayerModel').model.asset ?? undefined;

        data.skinUrl = this.userSkinUrl;
        data.vecLookAt = this.vecLookAt;

        data.f = 0;
        if (this.user.isFlight)
            data.f = 1;

        data.j = 0;
        if (this.user.isJumping)
            data.j = 1;

        data.t = 0;
        if (this.user.isTeleport) {
            this.user.isTeleport = false;
            data.t = 1;
        }

        this.position.copy(this.user.currentPosition);
        data.p = [
            Math.round(+this.position.x.toFixed(3) * 1000),
            Math.round(+this.position.y.toFixed(3) * 1000),
            Math.round(+this.position.z.toFixed(3) * 1000)
        ];


        this.angle = this.calculateYAxisAngle();
        data.a = this.angle;

        this.app.coreScript.compressArray_Delta(data.p);

        this.raiseEvent(data);
    }

    calculateYAxisAngle() {
        var Nx = this.user.entity.forward.x;
        var Nz = this.user.entity.forward.z;

        var magnitudeN = Math.sqrt(Nx * Nx + Nz * Nz);

        var angle = Math.acos(Nx / (magnitudeN)) * pc.math.RAD_TO_DEG;

        var crossY = Nz;
        if (crossY < 0) {
            angle = 360 - angle;
        }

        return angle;
    }

    raiseEvent(data) {
        if (this.timeout > 0.0)
            return;

        // console.log("raiseEvent!!");
        this.app.photonClient.raiseEvent(0, data);
        this.timeout = 0.2;
        this.sended = true;
    }
}