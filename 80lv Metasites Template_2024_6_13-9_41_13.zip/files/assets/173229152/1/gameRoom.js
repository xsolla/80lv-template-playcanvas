class GameRoom {
    constructor(app) {
        this.app = app;
        this.user = null;
        this.actors = [];

        this.app.on("photonClient:onJoinRoom", this.onJoinRoom, this);
        this.app.on("photonClient:onActorJoin", this.onActorJoin, this);
        this.app.on("photonClient:onActorLeave", this.removePlayer, this);
        this.app.on("photonClient:onUpdatePlayerPosition", this.updatePlayer, this);

        this.app.once('users:isInitialized', () => {
            this.user = this.app.selfUser.script.user;
            this.playerListUpdate();
        });
    }


    onJoinRoom() {
        const { name } = this.app.photonClient.myRoom();
        console.log('Photon: Current Room: ' + name);
        // this.entity.findByName("RoomName").element.text = name;
        this.playerListUpdate();
    }


    onActorJoin(actor) {
        if (actor.isLocal) {
            this.playerListUpdate();
        } else {
            this.app.fire('user:add', actor.actorNr, false);
            setTimeout(() => {
                this.app.fire("photonClient:raiseEvent");
            }, 500);
        }
    }


    removePlayer(actor) {
        this.app.fire('user:remove', actor.actorNr);
    }


    updatePlayer(data, actorNr) {
        if (this.user === null) 
            return;

        if (data.fps !== undefined)
            this.app.fire('user:setFps', actorNr, data.fps);

        if (data.ping !== undefined)
            this.app.fire('user:setPing', actorNr, data.ping);

        if (data.name !== undefined)
            this.app.fire('user:setName', actorNr, data.name.slice(0,5));

        // if (data.s !== undefined) 
        //     this.app.fire('user:setSkin', actorNr, data.s);
        if (data.skinUrl !== undefined) {
            this.app.fire('user:setSkin', actorNr, data.skinUrl);
        }

        if (data.f !== undefined) 
            this.app.fire('user:setFlight', actorNr, data.f);

        if (data.j !== undefined) 
            this.app.fire('user:setJumping', actorNr, data.j);

        if (data.p !== undefined) {
            this.app.coreScript.decompressArray_Delta(data.p, 'Int32Array');
            for (let i = 0; i < data.p.length; i++) {
                data.p[i] = data.p[i]/1000;
            }

            if (data.t !== undefined && data.t === 1) {
                this.app.fire('user:setTransform', actorNr, {position: data.p});
            } else {
                this.app.fire('user:setTargetTransform', actorNr, {position: data.p});
            }
        }

        if (data.a) {
            this.app.fire('user:setAngle', actorNr, { angle: data.a });
        }
    }


    playerListUpdate() {
        if (this.user === null) 
            return;

        this.actors = Object.values(this.app.photonClient.myRoomActors());
        for (let i = 0; i < this.actors.length; i++) {
            const actor = this.actors[i];
            if (!actor.isLocal) {
                this.app.fire('user:add', actor.actorNr, false);
                continue;
            }

            if (this.user.userId === actor.actorNr) 
                continue;

            this.app.fire('user:add', actor.actorNr, true);
        }
    }
}