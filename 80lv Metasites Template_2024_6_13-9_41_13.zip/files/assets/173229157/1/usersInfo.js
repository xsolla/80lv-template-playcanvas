const UsersInfo = pc.createScript('usersInfo');

UsersInfo.attributes.add('tplUser', {
    type: 'asset',
    assetType: 'template'
});


UsersInfo.prototype.init = function() {
    const layerWorld = this.app.scene.layers.getLayerByName('World').id;
    const batchGroup = this.app.batcher.addGroup('Userinfo', true, 100);
    batchGroup.layers = [layerWorld];
    this.batchGroupId = batchGroup.id;

    this.transformVS = this.app.assets.find('usersInfo_transformVS.glsl', 'shader').resource;
    this.transformVSBatch = this.app.assets.find('usersInfo_transformVS_Batch.glsl', 'shader').resource;

    this.usedPool = {};
    this.removedPool = [];
    this.tempPool = [];

    this.markDirty = false;
    this.checkDirty = false;
    this.checkDirtyTime = 0.0;
    this.checkNew = false;
    this.checkNewTime = 4.0;
    this.removeTime = 0.0;
    this.destroyTime = 0.0;

    CoreScript.mainCamera.script.onPreRender.onPreRender1 = () => {
        if (!this.markDirty) 
            return;

        this.markDirty = false;
        this.recreateBatch();
        this.patchBatchMaterial();
    }
};


UsersInfo.prototype.update = function(dt) {
    this.checkDirtyTime += dt;
    if (this.checkDirtyTime > 1.0) {
        this.checkDirtyTime = 0.0;
        this.checkDirty = true;
    }

    this.checkNewTime += dt;
    if (this.checkNewTime > 4.0) {
        this.checkNewTime = 0.0;
        this.checkNew = true;
    }

    for (const key in this.usedPool) {
        const item = this.usedPool[key];
        if (!item || !item.user) 
            continue;

        if (this.checkDirty) {
            // if (item.info.tFps !== item.info.fps) {
            //     item.info.fps = item.info.tFps;
            //     this.setInfo(item.info);
            //     if (item.info.element.batchGroupId !== -1) 
            //         this.markDirty = true;
            // }

            // if (item.info.tPing !== item.info.ping) {
            //     item.info.ping = item.info.tPing;
            //     this.setInfo(item.info);
            //     if (item.info.element.batchGroupId !== -1) 
            //         this.markDirty = true;
            // }

            if (item.name.element.text !== item.name.tName) {
                item.name.element.text = item.name.tName;
                if (item.name.element.batchGroupId !== -1) 
                    this.markDirty = true;
            }
        }

        if (!this.checkNew) 
            continue;

        if (item.name.element.batchGroupId === -1) {
            item.name.element.batchGroupId = this.batchGroupId;
            this.markDirty = true;
        }
        
        if (item.info.element.batchGroupId === -1) {
            item.info.element.batchGroupId = this.batchGroupId;
            this.markDirty = true;
        }

        if (item.info.tFps !== item.info.fps) {
            item.info.fps = item.info.tFps;
            this.setInfo(item.info);
            this.markDirty = true;
        }

        if (item.info.tPing !== item.info.ping) {
            item.info.ping = item.info.tPing;
            this.setInfo(item.info);
            this.markDirty = true;
        }
    }
    this.checkDirty = false;
    this.checkNew = false;


    this.removeTime += dt;
    if (this.removeTime > 4.0) {
        this.removeTime = 0.0;
 
        for (let i = 0; i < this.removedPool.length; i++) {
            const item = this.removedPool.splice(i, 1)[0];
            i--;
            
            item.info.element.batchGroupId = -1;
            item.name.element.batchGroupId = -1;
            item.info.parent.enabled = false;
            this.tempPool.push(item);
            this.markDirty = true;
        }
    }

    if (this.markDirty)
        this.app.batcher.markGroupDirty(this.batchGroupId);


    this.destroyTime += dt;
    if (this.destroyTime > 1.0) {
        this.destroyTime = 0.0;

        for (let i = 0; i < 64; i++) {
            if (this.tempPool.length <= 64)
                break;

            const item = this.tempPool.pop();
            item.info.parent.destroy();
        }
    }
};


UsersInfo.prototype.addItem = function(userId, user, name, fps, ping, selfUser) {
    if (this.tempPool.length <= 0) {
        for (let i = 0; i < 8; i++) {
            const entity = this.tplUser.resource.instantiate();
            this.app.scene.root.addChild(entity);

            const item = {
                name: entity.findByName('Name'),
                info: entity.findByName('Info'),
                user: user,
                t: 0.0
            };
            item.info.tFps = 0;
            item.info.fps = 0;
            item.info.tPing = 0;
            item.info.ping = 0;
            item.name.tName = '';

            item.info.element.batchGroupId = -1;
            item.name.element.batchGroupId = -1;
            this.patchMaterial(item.info);
            this.patchMaterial(item.name);
            item.info.parent.enabled = false;
            this.tempPool.push(item);
        }
    }

    const item = this.tempPool.pop();
    item.info.tFps = fps;
    item.info.fps = fps;
    item.info.tPing = ping;
    item.info.ping = ping;
    item.name.tName = name;
    this.setInfo(item.info);
    item.name.element.text = item.name.tName;

    item.info.parent.enabled = true;
    item.info.parent.setLocalScale(1.0, 1.0, 1.0);

    this.usedPool[userId] = item;

    if (selfUser)
        this.app.selfUserInfo = item;
};


UsersInfo.prototype.removeItem = function(userId) {
    const item = this.usedPool[userId];
    if (!item)
        return;

    item.info.parent.setLocalScale(0.0, 0.0, 0.0);
    this.removedPool.push(item);
    delete this.usedPool[userId];
};


UsersInfo.prototype.setFps  = function(userId, value) {
    const item = this.usedPool[userId];
    if (!item)
        return;

    item.info.tFps = value;
};


UsersInfo.prototype.setPing  = function(userId, value) {
    const item = this.usedPool[userId];
    if (!item)
        return;

    item.info.tPing = value;
};


UsersInfo.prototype.setName = function (userId, value) {
    const item = this.usedPool[userId];
    if (!item)
        return;

    item.name.tName = value;
};


UsersInfo.prototype.setInfo  = function(item) {
    if (item.ping < 100) {
        item.element.color = pc.Color.GREEN;
    } else if (item.ping < 250) {
        item.element.color = pc.Color.YELLOW;
    } else if (item.ping < 1000) {
        item.element.color = new pc.Color(1.0, 0.55, 0.0, 1.0);
    } else {
        item.element.color = pc.Color.RED;
    }
    item.element.text = '';
    // item.element.text = 'Ping: ' + item.ping + 'ms  FPS: ' + item.fps;
};


UsersInfo.prototype.setPosition = function(userId, position, height) {
    const item = this.usedPool[userId];
    if (!item) 
        return;

    item.info.parent.setPosition(position.x, position.y + height, position.z);
};


UsersInfo.prototype.patchMaterial = function(entity) {
    const material = entity.element._text._material;
    material.chunks.transformVS = this.transformVS;
    material.chunks.APIVersion = pc.CHUNKAPI_1_65;
    material.update();
};


UsersInfo.prototype.recreateBatch = function() {
    if (this.app.batcher._dirtyGroups.length <= 0)
        return;

    for (let i = 0; i < this.app.batcher._dirtyGroups.length; i++) {
        if (this.app.batcher._dirtyGroups[i] !== this.batchGroupId)
            continue;

        this.app.batcher.generate([this.app.batcher._dirtyGroups[i]]);
        break;
    }
};


UsersInfo.prototype.patchBatchMaterial = function() {
    for (let i = 0; i < this.app.batcher._batchList.length; i++) {
        const batch = this.app.batcher._batchList[i];
        if (batch.batchGroupId !== this.batchGroupId) 
            continue;

        batch.meshInstance._material.chunks.transformVS = this.transformVSBatch;
        batch.meshInstance._material.update();
    }
};