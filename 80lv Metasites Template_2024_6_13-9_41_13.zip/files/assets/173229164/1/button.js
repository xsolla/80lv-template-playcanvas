const Button = pc.createScript('button');


Button.prototype.initialize = function() {
    this.entity.element.on('click', (evt) => {
        this.app.fire('buttonClick', this.entity.name);
    });
};
