const ButtonAnim = pc.createScript('buttonAnim');

ButtonAnim.attributes.add('animShow', {
    type: 'json',
    schema: [{
        name: 'time',
        type: 'number', 
        default: 1.0 
    }, {
        name: 'playOnStart',
        type: 'boolean',
        default: true
    }, {
        name: 'ended',
        type: 'boolean',
        default: false
    }, {
        name: 'sclParent',
        type: 'curve',
        curves: [ 'x' ],
        default: {
            keys: [
                [0, 0, 1, 1],
                // [1, 1]
            ]
        }
    }, {
        name: 'sclStick',
        type: 'curve',
        curves: [ 'x' ],
        default: {
            keys: [
                [0, 0, 1, 1],
                // [1, 1]
            ]
        }
    }]
});


ButtonAnim.prototype.initialize = function() {
    if (!this.app.touch || pc.platform.desktop) {
        this.entity.parent.enabled = false;
        return;
    }

    this.animTime = 0.0;
    if (!this.animShow.ended && this.animShow.playOnStart) {
        const t = 0.0;
        const sclParent = this.animShow.sclParent.value(t);
        this.entity.parent.element.width = 128*sclParent;
        this.entity.parent.element.height = 128*sclParent;

        const sclStick = this.animShow.sclStick.value(t);
        this.entity.element.width = 110*sclStick;
        this.entity.element.height = 110*sclStick;
    }
    // this.animShow.playOnStart = false;

    // this.app.once('inputForm:setUsername', () => {
        this.animShow.playOnStart = true;
    // });
};


ButtonAnim.prototype.update = function(dt) {
    if (!this.animShow.ended && this.animShow.playOnStart) {
        this.animTime += dt;
        let t = this.animTime / this.animShow.time;
        if (t > 1.0) {
            t = 1.0;
            this.animShow.ended = true;
        }

        const sclParent = this.animShow.sclParent.value(t);
        this.entity.parent.element.width = 128*sclParent;
        this.entity.parent.element.height = 128*sclParent;

        const sclStick = this.animShow.sclStick.value(t);
        this.entity.element.width = 110*sclStick;
        this.entity.element.height = 110*sclStick;
    }
};
