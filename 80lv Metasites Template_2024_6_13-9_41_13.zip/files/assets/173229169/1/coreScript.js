const CoreScript = pc.createScript('coreScript');

CoreScript.mainCamera = null;
CoreScript.users = null;
CoreScript.usersInfo = null;
CoreScript.userSkins = null;


CoreScript.prototype.initialize = function() {
    this.init();
};


CoreScript.prototype.init = function() {
    this.vec3A = new pc.Vec3();

    const createArray = (arrayType, size) => {
        if (arrayType === 'Int32Array') return new Int32Array(size);
        if (arrayType === 'Int16Array') return new Int16Array(size);
        if (arrayType === 'Uint8Array') return new Uint8Array(size);

        return new Int32Array(size);
    };

    const lerp = (a, b, s, threshold) => {
        const value = a + s*(b - a);
        if (threshold !== undefined && Math.abs(value - b) < threshold) {
            return b;
        }
        return value;
    };

    const compressArray_Delta = (arr) => {
        if (!arr || arr.length === 0) return [];

        const result = [arr[0]];
        for (let i = 1; i < arr.length; i++) {
            result.push(arr[i] - arr[i - 1]);
        }
        return result;
    };

    const decompressArray_Delta = (compressedArr, arrayType) => {
        if (!compressedArr || compressedArr.length === 0) return new Uint8Array(0);

        const result = createArray(arrayType, compressedArr.length);
        result[0] = compressedArr[0];

        for (let i = 1; i < compressedArr.length; i++) {
            result[i] = (result[i - 1] + compressedArr[i]);
        }
        return result;
    };

    this.app.coreScript = {
        lerp: lerp,
        compressArray_Delta: compressArray_Delta,
        decompressArray_Delta: decompressArray_Delta
    };


    CoreScript.mainCamera = this.app.scene.root.findByTag('MainCamera')[0];
    CoreScript.mainCamera.script.onPreRender.init();

    const users = this.app.scene.root.findByName('Users');
    CoreScript.usersInfo = users.script.usersInfo;
    CoreScript.usersInfo.init();

    CoreScript.userSkins = users.script.userSkins;
    CoreScript.userSkins.init();

    CoreScript.users = users.script.users;
    CoreScript.users.initUsers();
};
