const PlayerMovement = pc.createScript('playerMovement');

PlayerMovement.attributes.add('flightMode', {
    type: 'boolean',
    default: false
});

PlayerMovement.attributes.add('jumpButton', {
    type: 'entity'
});

PlayerMovement.attributes.add('joystickName', {
    type: 'string'
});


PlayerMovement.prototype.postInitialize = function () {
    this.mainUser = null;
    this.worldDirection = new pc.Vec3();
    this.tempDirection = new pc.Vec3(); 
    this.vec3A = new pc.Vec3();
    this.speedCurrent = 0.0;

    if (this.flightMode) {
        this.isFlightModeKey = 0;
        this.isFlightModeKeyTime = 0;
        this.isFlightModeKeyTimeout = 300;
        // this.isFlightMode = true;
        this.isFlightMode = false;
    }

    this.isJumping = false;
    // const jumpButton = this.app.scene.root.findByName('JumpButton');
    // // const flightButton = this.app.scene.root.findByName('FlightButton');

    // if (this.app.touch) {
        this.joystickData = {};
        this.app.on('joystickControl:isPressed', (data) => {
            if (data.name !== this.joystickName) 
                return;

            this.joystickData = data;

            if (this.jumpButton && this.jumpButton.enabled) 
                return;

            if (!data.isPressed) {
                this.isJumping = false;
                if (data.ring) this.isJumping = true;
            }
        });

        if (this.jumpButton && this.jumpButton.enabled) {
            this.jumpButton.findByName('Button').button.on('touchstart', () => {
                this.isJumping = true;

                if (!this.flightMode) 
                    return;

                const now = Date.now();
                if (this.isFlightModeKey === 0) {
                    this.isFlightModeKey++;
                    this.isFlightModeKeyTime = now;
                } else {
                    this.isFlightModeKey = 0;
                    if (now - this.isFlightModeKeyTime <= this.isFlightModeKeyTimeout)
                        this.isFlightMode = true;
                }
            });
            this.jumpButton.findByName('Button').button.on('touchleave', () => {
                this.isJumping = false;
            });
            this.jumpButton.findByName('Button').button.on('touchend', () => {
                this.isJumping = false;
            });
            this.jumpButton.findByName('Button').button.on('touchcancel', () => {
                this.isJumping = false;
            });
        }

        // // flightButton.findByName('Button').button.on('click', () => {
        // //     if (!this.isFlightMode)
        // //         this.isFlightMode = true; 
        // // });
    // } else {
    //     // jumpButton.enabled = false;
    //     // // flightButton.enabled = false;
    //     // // return;
    // }

    // this.app.on('flightMode', () => {
    //     this.isFlightMode = true;
    // });

    // this.isActive = false;
    // this.app.once('inputForm:setUsername', () => {
        this.isActive = true;
    // });
};


PlayerMovement.prototype.update = function (dt) {
    if (!this.mainUser) {
        this.mainUser = this.app.scene.root.findByTag('MainUser')[0];
        return;
    }

    if (!this.isActive) {
        this.mainUser.script.user.isJumping = false;
        return;
    }


    this.worldDirection.set(0, 0, 0);
    let x = 0;
    let z = 0; 

    // joystick
    if (this.joystickData.x && this.joystickData.x !== 0.0) 
        x = Math.pow(this.joystickData.x, 2.0) * Math.sign(this.joystickData.x);

    if (this.joystickData.y && this.joystickData.y !== 0.0)
        z = Math.pow(this.joystickData.y, 2.0) * Math.sign(this.joystickData.y);

    // keyboard
    this.onlineChatInputElement = document.querySelector('.chat_input');
    this.spotifySearchElement = document.querySelector('.spotify_search_input');

    let keyboard = false;
    if (
        document.activeElement === this.onlineChatInputElement ||
        document.activeElement === this.spotifySearchElement
    ) return;

    if (this.app.keyboard.isPressed(pc.KEY_A)) {
        keyboard = true;
        x -= 1;
    }

    if (this.app.keyboard.isPressed(pc.KEY_D)) {
        keyboard = true;
        x += 1;
    }

    if (this.app.keyboard.isPressed(pc.KEY_W)) {
        keyboard = true;
        z += 1;
    }

    if (this.app.keyboard.isPressed(pc.KEY_S)) {
        keyboard = true;
        z -= 1;
    }

    

    if (x !== 0 || z !== 0) {
        this.computeWorldDirection(x, z);

        let movementControl = 1.0;
        if (keyboard) {
            if (this.app.keyboard.isPressed(pc.KEY_SHIFT))
                movementControl = 2.0;
        } else {
            movementControl = this.worldDirection.length()*2.0;
        }

        this.worldDirection.normalize();
        this.mainUser.script.user.setTargetPosByDirection([this.worldDirection.x, this.worldDirection.y, this.worldDirection.z], movementControl);

        if (!this.jumpButton ||(this.jumpButton && !this.jumpButton.enabled)) {
            if (this.isJumping && !this.joystickData.ring && !this.mainUser.script.user.isJumping) {
                this.isJumping = false;
                this.joystickData = {};
            }
        }
    } else {
        this.mainUser.script.user.stopMovement();
    }


    if (this.jumpButton && this.jumpButton.enabled) {
        if (!this.mainUser.script.user.isFlightMode) {
            if (this.app.keyboard.wasPressed(pc.KEY_SPACE) || this.isJumping) {
                this.mainUser.script.user.jump();
                this.isJumping = false;
            }
        } else if (this.mainUser.script.user.isFlight) {
            if (this.app.keyboard.isPressed(pc.KEY_SPACE) || this.isJumping) {
                this.mainUser.script.user.isJumping = true;
            } else {
                this.mainUser.script.user.isJumping = false;
            }
        }
    } else {
        if (!this.mainUser.script.user.isFlightMode) {
            if (this.app.keyboard.wasPressed(pc.KEY_SPACE) || this.joystickData.ring) {
                this.mainUser.script.user.jump();
                this.joystickData.ring = false;
            }
        } else if (this.mainUser.script.user.isFlight) {
            if (this.app.keyboard.isPressed(pc.KEY_SPACE) || this.joystickData.ring) {
                this.mainUser.script.user.isJumping = true;
            } else {
                this.mainUser.script.user.isJumping = false;
            }
        }
    }


    if (this.flightMode) {
        const now = Date.now();
        if (this.app.keyboard.wasPressed(pc.KEY_SPACE)) {
            if (this.isFlightModeKey === 0) {
                this.isFlightModeKey++;
                this.isFlightModeKeyTime = now;
            } else {
                this.isFlightModeKey = 0;
                if (now - this.isFlightModeKeyTime <= this.isFlightModeKeyTimeout)
                    this.isFlightMode = true;
            }
        }

        if (this.isFlightModeKey > 0) {
            if (now - this.isFlightModeKeyTime > this.isFlightModeKeyTimeout)
                this.isFlightModeKey = 0;
        }

        if (this.isFlightMode) {
            this.mainUser.script.user.flightMode();
            this.mainUser.script.user.jump();
            this.isFlightMode = false;
        }
    }
    

    if (this.app.keyboard.wasPressed(pc.KEY_R)) {
        this.mainUser.script.user.respawn();
        this.entity.script.thirdPersonCamera.respawn();
    }
};


PlayerMovement.prototype.computeWorldDirection = function (x, z) {
    this.tempDirection.copy(this.entity.forward);
    if (!this.mainUser.script.user.isFlightMode) {
        this.tempDirection.y = 0.0;
        this.tempDirection.normalize();
    }
    this.worldDirection.add(this.tempDirection.mulScalar(z));

    this.tempDirection.copy(this.entity.right);
    if (!this.mainUser.script.user.isFlightMode) {
        this.tempDirection.y = 0.0;
        this.tempDirection.normalize();
    }
    this.worldDirection.add(this.tempDirection.mulScalar(x));
};
