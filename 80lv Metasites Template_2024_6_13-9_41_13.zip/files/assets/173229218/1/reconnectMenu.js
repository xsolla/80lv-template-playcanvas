const ReconnectMenu = pc.createScript('reconnectMenu');


ReconnectMenu.prototype.initialize = function() {
    this.app.on('photonClient:onError', (errorCode) => {
        this.reconnect();
    });
};


ReconnectMenu.prototype.reconnect = function() {
    this.app.photonLoadBalancing.reconnectToMaster();
};
