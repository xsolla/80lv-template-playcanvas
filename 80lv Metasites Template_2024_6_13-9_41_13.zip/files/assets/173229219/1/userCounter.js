const UserCounter = pc.createScript('userCounter');

UserCounter.userCount = 0;


UserCounter.prototype.initialize = function () {
    const counterContainer = document.createElement('div');
    counterContainer.id = 'userCounter';
    counterContainer.innerText = '';

    counterContainer.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="8" height="9" viewBox="0 0 8 9" fill="none">
            <circle id="online_indicator" cx="4" cy="4.5" r="4" fill="red"/>
        </svg>
    `;

    this.userCounter = document.createElement('text');
    counterContainer.appendChild(this.userCounter);
    document.body.appendChild(counterContainer);

    this.onlineIdicator = counterContainer.querySelector('#online_indicator');

    const css = [
        `#userCounter {
            border-radius: 90px;
            background: var(--blue-64, rgba(6, 7, 34, 0.64));
            pointer-events: none;
            position: absolute;
            top: 28px;
            left: 50%;
            transform: translateX(-50%);
            width: auto;
            display: flex;
            flex-direction: row;
            align-items: center;
            gap: 10px;
            padding: 6px 12px 7px 12px;
        }`,
        `#userCounter text {
            color: #FFF;
            text-align: center;
            font-size: 14px;
            font-style: normal;
            font-weight: 500;
            line-height: normal;
            letter-spacing: 0.28px;
        }`,
        `@media(max-width: 667px) {
            #userCounter {
                left: 16px;
                transform: translateX(0);
                top: 86px;
            }
        }`
    ].join('\n');

    const style = document.createElement('style');
    style.type = 'text/css';
    if (style.styleSheet) {
        style.styleSheet.cssText = css;
    } else {
        style.appendChild(document.createTextNode(css));
    }

    document.head.appendChild(style);

    this.userCount = 0;
    this.roomCount = 0;
};


UserCounter.prototype.update = function (dt) {
    let roomCount = 0;
    if (this.app.photonClient) {
        const myRoom = this.app.photonClient.myRoom();
        if (myRoom) roomCount++;

        const rooms = this.app.photonClient.availableRooms();
        if (rooms) {
            for (let i = 0; i < rooms.length; i++) {
                if (rooms[i].name !== myRoom.name)
                    roomCount++;
            }
        }
    }

    if (this.roomCount === roomCount && this.userCount === UserCounter.userCount)
        return;

    this.roomCount = roomCount;
    this.userCount = UserCounter.userCount;
    this.userCounter.innerText = UserCounter.userCount + ' online';

    const state = this.app.photonClient.state;

    if ([Photon.LoadBalancing.LoadBalancingClient.State.Error, Photon.LoadBalancing.LoadBalancingClient.State.Disconnected].includes(state)) {
        this.setOnlineStatus(false);
    } else if (state === Photon.LoadBalancing.LoadBalancingClient.State.Joined || state === Photon.LoadBalancing.LoadBalancingClient.State.ConnectedToGameserver) {
        this.setOnlineStatus(true);
    }
};

UserCounter.prototype.setOnlineStatus = function (isOnline) {
    this.onlineIdicator.style.fill = isOnline ? '#03FF76' : 'red';
}
