var Fps = pc.createScript('fps');
Fps.attributes.add('css', { type: 'asset', assetType: 'css', title: 'CSS Asset' });

Fps.prototype.initialize = function() {
    var style = document.createElement('style');
    document.head.appendChild(style);
    style.innerHTML = this.css.resource || '';

    this._fps = 0;
    this.fps = 0;
    
    const fpsDisplay = document.createElement('div');
    fpsDisplay.style.position = 'absolute';
    fpsDisplay.style.top = pc.platform.mobile ? '180px': '146px';
    fpsDisplay.style.left = pc.platform.mobile ? '16px' : '28px';
    fpsDisplay.style.color = '#fff';
    document.body.appendChild(fpsDisplay);

    fpsDisplay.innerHTML = `
        <div class="fps_title">FPS</div>
    `;

    this.fpsEl = document.createElement('div');

    this.fpsEl.classList.add('fps_number');

    fpsDisplay.appendChild(this.fpsEl);
    
    setInterval(function () {
        this.fpsEl.textContent = this.fps;
        this.fps = this._fps;
        this._fps = 0;
    }.bind(this), 1000);
};

Fps.prototype.update = function(dt) {
    this._fps++;
};