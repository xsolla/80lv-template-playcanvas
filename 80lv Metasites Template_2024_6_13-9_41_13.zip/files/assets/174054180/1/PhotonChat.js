class PhotonChatPlayCanvas extends pc.ScriptType {
    initialize() {
        this.roomName = Environments.roomName;
        this.region = Environments.region;

        const { wss, appId, appVersion } = {
            appId: Environments.photonChatAppID,
            appVersion: this.appVersion,
            wss: this.wss ? 1 : 0
        };

        this.chat = new Photon.Chat.ChatClient(wss, appId, appVersion);
        this.chat.app = this.app;

        this.setupEventListeners();

        // Get Random name;
        const animals = ['lion', 'tiger', 'cheetah', 'giraffe', 'elephant', 'monkey', 'hippopotamus', 'bear', 'zebra', 'kangaroo', 'penguin', 'flamingo', 'pelican', 'octopus', 'squid', 'whale', 'dolphin', 'shark', 'turtle', 'crab', 'lobster', 'scorpion', 'snake', 'lizard', 'chameleon', 'owl', 'bat', 'pegasus', 'unicorn', 'dragon'];
        const userId = animals[Math.floor(Math.random() * animals.length)];
        this.app.fire("chat:join", userId);
    }

    setupEventListeners() {
        this.app.on("chat:connected", this.connected, this);
        this.app.on("chat:subscribed", this.subscribed, this);
        this.app.on("chat:join", this.join, this);
        this.app.on("chat:send", this.send, this);

        this.chat.onChatMessages = this.onChatMessages.bind(this);
        this.chat.onStateChange = this.onStateChange.bind(this);
        this.chat.onUserSubscribe = this.onUserSubscribe.bind(this);
    }

    onUserSubscribe(channelName, userId) {
        this.app.fire("chat:subscribed");
    }

    onStateChange(state) {
        if (state === 4) {
            this.app.fire("chat:connected");
        }
    }

    onChatMessages(channelName, messages) {
        const messageValues = Object.values(messages);
        this.app.fire("ui:chat:render", messageValues);
    }

    join(userId) {
        this.chat.setUserId(userId || this.app.userName);
        this.chat.connectToRegionFrontEnd(this.region);
    }

    connected() {
        this.chat.subscribe([this.roomName], { historyLength: 10 });
        this.app.fire("chat:subscribed");
    }

    send(message) {
        this.chat.publishMessage(this.roomName, message);
    }

    subscribed() {
        this.chat.publishMessage(this.roomName, `${this.chat.getUserId()} is Joined`);
    }
}

pc.registerScript(PhotonChatPlayCanvas);
PhotonChatPlayCanvas.attributes.add('appVersion', { type: 'string', default: '1.0' });
PhotonChatPlayCanvas.attributes.add('wss', { type: 'boolean', default: true });