const FirstPersonCamera = pc.createScript('firstPersonCamera');

FirstPersonCamera.attributes.add('joystickMove', {
  type: 'entity'
});

FirstPersonCamera.attributes.add('height', {
  type: 'number',
  min: 0.0, max: 2.0,
  default: 1.0
});

FirstPersonCamera.attributes.add('mouseSpeed', {
  type: 'number',
  default: 1.4,
  description: 'Mouse Sensitivity'
});

FirstPersonCamera.attributes.add('touchSpeed', {
  type: 'number',
  default: 5.6,
  description: 'Touch Sensitivity'
});

FirstPersonCamera.attributes.add('zoom', {
  type: 'json',
  schema: [{
    name: 'default',
    type: 'number',
    default: 8.0
  }, {
    name: 'min',
    type: 'number',
    default: 2.0
  }, {
    name: 'max',
    type: 'number',
    default: 64.0
  }, {
    name: 'mouseSensitivity',
    type: 'number',
    default: 1.0
  }, {
    name: 'touchSensitivity',
    type: 'number',
    default: 0.1
  }]
});


FirstPersonCamera.prototype.postInitialize = function () {
  this.postInit();
};


FirstPersonCamera.prototype.postInit = function () {
  this.mainUser = null;
  this.camera = this.app.scene.root.findByTag('MainCamera')[0];
  this.rayEnd = this.app.scene.root.findByName('RaycastEndPoint');
  this.rayEndTargetZ = this.zoom.default;
  this.rayEndCurrentZ = this.rayEndTargetZ;
  this.rayEnd.setPosition(0.0, 0.0, this.rayEndCurrentZ);

  this.quatA = new pc.Quat();
  this.forward = new pc.Vec3();
  this.lookAt = new pc.Vec3();

  this.mainUserPosition = new pc.Vec3();
  this.targetPos = new pc.Vec3();
  this.vec3A = new pc.Vec3();
  this.vec3B = new pc.Vec3();
  this.currentDistance = this.camera.getLocalPosition().z;

  if (this.app.touch && pc.platform.mobile) {
    this.device = this.app.graphicsDevice;
    this.touchesDistance = 0;
    this.prevTouchesDistance = 0;
    this.touches = [];
    for (let i = 0; i < 2; i++) {
      const touch = {
        id: -1,
        prevTouchCoords: new pc.Vec2(),
        touchCoords: new pc.Vec2(),
        touchDifference: new pc.Vec2(),
      }
      this.touches.push(touch);
    }

    this.app.touch.on(pc.EVENT_TOUCHSTART, this.onTouchStart, this);
    this.app.touch.on(pc.EVENT_TOUCHMOVE, this.onTouchMove, this);
    this.app.touch.on(pc.EVENT_TOUCHEND, this.onTouchEnd, this);
    this.app.touch.on(pc.EVENT_TOUCHCANCEL, this.onTouchCancel, this);
  } else {
    this.app.mouse.on(pc.EVENT_MOUSEWHEEL, this.onMouseWheel, this);
    this.app.mouse.on(pc.EVENT_MOUSEMOVE, this.onMouseMove, this);
    this.app.mouse.on(pc.EVENT_MOUSEDOWN, this.onMouseDown, this);

    this.on('destroy', () => {
      this.app.mouse.off(pc.EVENT_MOUSEWHEEL, this.onMouseWheel, this);
      this.app.mouse.off(pc.EVENT_MOUSEMOVE, this.onMouseMove, this);
      this.app.mouse.off(pc.EVENT_MOUSEDOWN, this.onMouseDown, this);
    }, this);
  }
};


FirstPersonCamera.prototype.postUpdate = function (dt) {
  if (!this.mainUser) {
    this.mainUser = this.app.scene.root.findByTag('MainUser')[0];
    if (this.mainUser) {
      this.height = this.mainUser.script.user.height * this.height;

      this.mainUserPosition.copy(this.mainUser.getPosition());
      this.mainUserPosition.y += this.height;
      this.entity.setPosition(this.mainUserPosition);
      this.respawn();
    }
    return;
  }

  // Обновляем позицию камеры
  this.mainUserPosition.copy(this.mainUser.getPosition());
  // 0.9 - сдвиг примерно уровень головы
  this.mainUserPosition.y += (this.height - 0.9);

  let forwardOffset = this.forward.clone().scale(0.5);
  this.mainUserPosition.add(forwardOffset);

  this.entity.setPosition(this.mainUserPosition);

  // Вычисляем точку взгляда для камеры
  this.lookAt.copy(this.forward);
  this.lookAt.add(this.mainUserPosition);

  // Ориентируем камеру на точку взгляда
  this.entity.lookAt(this.lookAt, pc.Vec3.UP);

  // Смотрим на точку взгляда
  this.camera.lookAt(this.lookAt, pc.Vec3.UP);

  // Локальная позиция камеры остается неизменной
  this.camera.setLocalPosition(0, 0, 0);
};


FirstPersonCamera.prototype.respawn = function () {
  this.forward.copy(this.mainUser.forward);
};


FirstPersonCamera.prototype.onMouseWheel = function (evt) {
  this.rayEndTargetZ -= evt.wheel * this.zoom.mouseSensitivity * (this.rayEndTargetZ * 0.1);
  this.rayEndTargetZ = this.rayEndTargetZ < this.zoom.min ? this.zoom.min : this.rayEndTargetZ;
  this.rayEndTargetZ = this.rayEndTargetZ > this.zoom.max ? this.zoom.max : this.rayEndTargetZ;
  evt.event.preventDefault();
};


FirstPersonCamera.prototype.onMouseMove = function (evt, fakeSpeed) {
  // TODO: ограничить угол поворота камеры по Y
  if (pc.Mouse.isPointerLocked() && this.cameraMode !== 'TDC') {
    this.forward.copy(this.entity.forward);
    this.quatA.setFromAxisAngle(this.entity.up, -evt.dx * (fakeSpeed ?? this.mouseSpeed) / 60);
    this.forward = this.quatA.transformVector(this.forward);
    this.quatA.setFromAxisAngle(this.entity.right, -evt.dy * (fakeSpeed ?? this.mouseSpeed) / 60);
    this.forward = this.quatA.transformVector(this.forward);
  }
};


FirstPersonCamera.prototype.onMouseDown = function (evt) {
  if (evt.element.id === 'chat_input') {
    return;
  }

  if (evt.element.id === 'application-canvas') {
    this.app.mouse.enablePointerLock();
  }
};


FirstPersonCamera.prototype.getWorldPoint = function () {
  this.vec3A.copy(this.rayEnd.getPosition());
  if (this.vec3A.y < 0.5) {
    const distA = this.mainUserPosition.y - 0.5;
    const distB = this.mainUserPosition.y - this.vec3A.y;

    this.vec3A.sub(this.mainUserPosition);
    const length = this.vec3A.length() * (distA / distB);
    this.vec3A.normalize();
    this.vec3A.mulScalar(length);
    this.vec3A.add(this.mainUserPosition);
  }

  return this.vec3A;
};


FirstPersonCamera.prototype.getTouch = function (touches, touchId) {
  for (let i = 0; i < touches.length; i++) {
    const touch = touches[i];
    if (touch.id === touchId)
      return touch;
  }

  return null;
};


FirstPersonCamera.prototype.onTouchStart = function (evt) {
  if (this.joystickMove.script.joystick.touchId === evt.changedTouches[0].id)
    return;

  if (this.touches[0].id !== -1 && this.touches[1].id !== -1)
    return;

  const index = this.touches[0].id === -1 ? 0 : 1;
  const touch = this.touches[index];
  touch.id = evt.changedTouches[0].id;
  const changedTouch = this.getTouch(evt.changedTouches, touch.id);
  if (!changedTouch)
    return;

  touch.touchCoords.set(changedTouch.x, changedTouch.y);
  touch.prevTouchCoords.copy(touch.touchCoords);
  if (index === 1) {
    this.touchesDistance = this.touches[0].touchCoords.distance(touch.touchCoords);
    this.prevTouchesDistance = this.touchesDistance;
  }

  evt.event.preventDefault();
};


FirstPersonCamera.prototype.onTouchMove = function (evt) {
  if (this.touches[0].id !== -1 && this.touches[1].id !== -1) {
    for (let i = 0; i < this.touches.length; i++) {
      const touch = this.touches[i];
      const changedTouch = this.getTouch(evt.changedTouches, touch.id);
      if (!changedTouch)
        continue;

      touch.touchCoords.set(changedTouch.x, changedTouch.y);
      touch.touchDifference.copy(touch.touchCoords);
      touch.touchDifference.sub(touch.prevTouchCoords);
      touch.prevTouchCoords.copy(touch.touchCoords);
    }

    this.touchesDistance = this.touches[0].touchCoords.distance(this.touches[1].touchCoords);
    const touchesDifference = this.touchesDistance - this.prevTouchesDistance;
    this.prevTouchesDistance = this.touchesDistance;

    this.rayEndTargetZ -= touchesDifference * this.zoom.touchSensitivity * (this.rayEndTargetZ * 0.1);
    this.rayEndTargetZ = this.rayEndTargetZ < this.zoom.min ? this.zoom.min : this.rayEndTargetZ;
    this.rayEndTargetZ = this.rayEndTargetZ > this.zoom.max ? this.zoom.max : this.rayEndTargetZ;

    evt.event.preventDefault();
  } else {
    const touch = this.touches[0];
    const changedTouch = this.getTouch(evt.changedTouches, touch.id);
    if (!changedTouch)
      return;

    touch.touchCoords.set(changedTouch.x, changedTouch.y);
    touch.touchDifference.copy(touch.touchCoords);
    touch.touchDifference.sub(touch.prevTouchCoords);
    touch.prevTouchCoords.copy(touch.touchCoords);

    this.forward.copy(this.entity.forward);
    this.quatA.setFromAxisAngle(this.entity.up, -(this.touchSpeed * touch.touchDifference.x) / 60);
    this.forward = this.quatA.transformVector(this.forward);
    this.quatA.setFromAxisAngle(this.entity.right, -(this.touchSpeed * touch.touchDifference.y) / 60);
    this.forward = this.quatA.transformVector(this.forward);

    evt.event.preventDefault();
  }
};


FirstPersonCamera.prototype.onTouchEnd = function (evt) {
  let done = false;
  for (let i = 0; i < this.touches.length; i++) {
    const touch = this.touches[i];
    const changedTouch = this.getTouch(evt.changedTouches, touch.id);
    if (!changedTouch)
      continue;

    touch.id = -1;
    done = true;
  }

  if (done) {
    this.touches.sort(function (a, b) {
      return b.id - a.id;
    });

    evt.event.preventDefault();
  }
};


FirstPersonCamera.prototype.onTouchCancel = function (evt) {
  let done = false;
  for (let i = 0; i < this.touches.length; i++) {
    const touch = this.touches[i];
    const changedTouch = this.getTouch(evt.changedTouches, touch.id);
    if (!changedTouch)
      continue;

    touch.id = -1;
    done = true;
  }

  if (done) {
    this.touches.sort(function (a, b) {
      return b.id - a.id;
    });

    evt.event.preventDefault();
  }
};
