var ControlInfo = pc.createScript('controlInfo');

ControlInfo.attributes.add('css', { type: 'asset', assetType: 'css', title: 'CSS Asset' });
ControlInfo.attributes.add('html', { type: 'asset', assetType: 'html', title: 'HTML Asset' });

// ControlInfo.attributes.add('a_icon', { type: 'asset', assetType: 'html', title: 'HTML Asset' });
// ControlInfo.attributes.add('w_icon', { type: 'asset', assetType: 'html', title: 'HTML Asset' });
// ControlInfo.attributes.add('s_icon', { type: 'asset', assetType: 'html', title: 'HTML Asset' });
// ControlInfo.attributes.add('d_icon', { type: 'asset', assetType: 'html', title: 'HTML Asset' });
// ControlInfo.attributes.add('v_icon', { type: 'asset', assetType: 'html', title: 'HTML Asset' });
// ControlInfo.attributes.add('space_icon', { type: 'asset', assetType: 'html', title: 'HTML Asset' });
// ControlInfo.attributes.add('esc_icon', { type: 'asset', assetType: 'html', title: 'HTML Asset' });


// initialize code called once per entity
ControlInfo.prototype.initialize = function() {
    const style = document.createElement('style');
    document.head.appendChild(style);
    style.innerHTML = this.css.resource || '';

    const controlInfoContainer = document.createElement('div');
    controlInfoContainer.classList.add('control_info_container');

    controlInfoContainer.innerHTML = this.html.resource || '';

    document.body.appendChild(controlInfoContainer);
};
