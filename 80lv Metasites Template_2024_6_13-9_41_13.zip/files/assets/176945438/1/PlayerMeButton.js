var PlayerMebutton = pc.createScript('playerMebutton');

PlayerMebutton.attributes.add('css', { type: 'asset', assetType: 'css', title: 'CSS Asset' });
PlayerMebutton.attributes.add('html', { type: 'asset', assetType: 'html', title: 'HTML Asset' });

PlayerMebutton.prototype.initialize = function() {
    var style = document.createElement('style');
    document.head.appendChild(style);
    style.innerHTML = this.css.resource || '';

    const characterButton = document.createElement('button');
    characterButton.classList.add('character');

    characterButton.innerHTML = this.html.resource || '';
    document.body.appendChild(characterButton);

    characterButton.addEventListener('click', this.onClick.bind(this));
    

    this.app.keyboard.on(pc.EVENT_KEYDOWN, this.onKeyDown, this);
};


PlayerMebutton.prototype.onClick = function() {
    this.app.fire('BtnManager:LoadAvatarButtonClick');
};

PlayerMebutton.prototype.onKeyDown = function (event) {
    if (event.key === pc.KEY_C && !window._chatting) {
        this.app.fire('BtnManager:LoadAvatarButtonClick');
    }
}