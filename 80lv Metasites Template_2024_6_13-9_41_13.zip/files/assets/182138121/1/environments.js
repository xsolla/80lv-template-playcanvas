var Environments = pc.createScript('environments');

Environments.attributes.add('region', { type: 'string', default: 'us' });
Environments.attributes.add('roomName', { type: 'string', default: 'room' });
Environments.attributes.add('photonChatAppID', { type: 'string' });
Environments.attributes.add('photonAppID', { type: 'string' });
Environments.attributes.add('odinAccessKey', { type: 'string' });
Environments.attributes.add('spotifyClientId', { type: 'string' });
Environments.attributes.add('spotifyClientSecret', { type: 'string' });

Environments.prototype.initialize = function() {
    Environments.region = this.region;
    Environments.roomName = this.roomName;
    Environments.photonChatAppID = this.photonChatAppID;
    Environments.photonAppID = this.photonAppID;
    Environments.odinAccessKey = this.odinAccessKey;
    Environments.spotifyClientId = this.spotifyClientId;
    Environments.spotifyClientSecret = this.spotifyClientSecret;

    console.log('Environments', this);
}