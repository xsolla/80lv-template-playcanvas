var IframeManager = pc.createScript('iframeManager');

IframeManager.prototype.initialize = function() {
    if (window.top === window) return;
    console.log('PC: INITIALIZE IFRAME MANAGER'); 

    const app = pc.Application.getApplication();
    const uiElementsNames = ['Online Chat', 'VoiceButton', 'Load Avatar Button', 'Spotify', 'PlayerMe'];
    this.uiElements = app.root.findByName('UI').children.filter(e => uiElementsNames.includes(e.name));
    this.toggleUiElements(false);

    this.app.on('PC:uiElements', this.toggleUiElements.bind(this));
    
    this.connect();
    
    this.app.on('iframe:sendMessage', function(type, data){
        
        this.sendMessage(type, data);        
    }, this);
};

IframeManager.prototype.toggleUiElements = function (isEnable) {
    this.uiElements.forEach(e => e.enabled = isEnable);
}

IframeManager.prototype.connect = function(){
    // --- when we use PC game with iframe, we have two level iframe
    window.addEventListener("message", function(event){
        this.parseMessage(event);
    }.bind(this));

    // --- inform parent window that we are ready
   this.sendMessage('PC:GameReady');
};

IframeManager.prototype.sendMessage = function(type, data){
    if( !type ) return;
    
    if (window !== window.top) window.top.postMessage({
        type: type,
        data: data
    }, '*');
};

IframeManager.prototype.parseMessage = function(event){
    if (!event.data) return;

    console.log('iframe event: ', event);
    // wait for data will be like { message: string, data: Record<string, any> }
    if (event.data.message) this.app.fire(event.data.message, event.data.data);
};